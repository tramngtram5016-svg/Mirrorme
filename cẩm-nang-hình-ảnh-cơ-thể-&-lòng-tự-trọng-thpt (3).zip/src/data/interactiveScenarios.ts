import { Scenario } from '../types';

export const SCENARIOS_DATA: Scenario[] = [
  {
    id: 'sc-1',
    title: 'Giờ Ra Chơi & Lời Trêu Chọc Ở Hành Lang',
    context: 'school',
    situation:
      'Trong giờ giải lao ở hành lang lớp học trước mặt nhiều bạn bè, một bạn nam trong lớp nhìn sang bạn rồi cười cợt, nói to: "Ê, dạo này ăn uống kiểu gì mà người như cái lu / que tăm vậy mày!". Cả nhóm bạn xung quanh bắt đầu nhìn về phía bạn và cười hùa theo.',
    quote: '"Ê dạo này ăn uống kiểu gì mà người như cái lu vậy, sắp lăn được rồi đấy haha!"',
    expertAdvice:
      'Lời khuyên từ cẩm nang: Tránh hai thái cực "im lặng cam chịu" (làm tăng nỗi lo âu kéo dài) và "công kích thù địch" (dễ leo thang xung đột vi phạm kỷ luật). Hãy vận dụng kỹ thuật The Cool Echo (hỏi ngược điềm tĩnh) hoặc đặt ranh giới trực diện.',
    suggestedPromptIdeas: [
      'Nhìn thẳng mắt bạn đó và hỏi ngược: "Cậu thấy việc đem cơ thể người khác ra làm trò cười là điều hay ho lắm hả?"',
      'Điềm đạm khẳng định: "Cơ thể mình khỏe mạnh để học tập là được. Mình không thích đùa về ngoại hình, tụi mình đổi chủ đề nhé."',
      'Bình thản làm mặt lạnh (Grey Rock), nói ngắn gọn rồi quay sang tiếp tục ôn bài với bạn bên cạnh.',
    ],
  },
  {
    id: 'sc-2',
    title: 'Giờ Học Thể Dục & Lời Chê Chậm Chạp / Thể Lực',
    context: 'school',
    situation:
      'Trong tiết thể dục môn chạy bền hoặc bóng rổ ngoài sân trường, vì mệt nên bạn thở dốc và hoàn thành lượt chạy muộn hơn các bạn. Một bạn cùng nhóm chạy đến cười cợt trước mặt cả lớp: "Người to như hộ pháp / lùn tịt thế kia bảo sao chạy chậm như rùa bò!".',
    quote: '"Người nặng nề thế kia bảo sao chạy chậm như rùa bò, kéo tụt điểm thi đua của cả tổ rồi kìa!"',
    expertAdvice:
      'Nguyên lý Body Neutrality: Cơ thể mỗi người có nhịp độ phát triển và sức bền khác nhau. Giá trị của việc tập thể dục là rèn luyện sức khỏe của chính bạn, không phải để làm vừa mắt hay chiều chuộng định kiến của người khác.',
    suggestedPromptIdeas: [
      'Thở đều 3 nhịp và đáp: "Mình đang nỗ lực hết sức để rèn luyện sức khỏe của mình. Sự nỗ lực đáng tôn trọng hơn lời chê bai."',
      'Nhắc nhở tinh thần đồng đội: "Thay vì chê bai làm bạn nản chí, cậu có thể cổ vũ để tổ mình cùng hoàn thành tốt hơn."',
      'Báo cáo giáo viên thể dục nếu hành vi này biến thành thói quen chèn ép thể lực có hệ thống.',
    ],
  },
  {
    id: 'sc-3',
    title: 'Bình Luận Soi Mói Dưới Ảnh Kỷ Yếu / Mạng Xã Hội',
    context: 'social_media',
    situation:
      'Bạn vừa đăng tấm ảnh chụp chung cùng bạn bè trong ngày hội trường lên trang cá nhân Facebook/Instagram. Dưới phần bình luận, một tài khoản cùng khóa để lại câu nhận xét: "Ủa dùng app gì kéo chân bóp mặt lộ thế? Ngoài đời nhìn chân ngắn với da mụn mà trên ảnh ảo lòi."',
    quote: '"Ủa dùng app gì kéo chân lộ liễu thế bạn? Ngoài đời chân ngắn da mụn mà trên ảnh ảo tung chảo haha!"',
    expertAdvice:
      'Chiến lược Tường lửa số (Digital Firewall): Trang cá nhân của bạn là không gian riêng tư của bạn. Bạn không có nghĩa vụ phải giải thích hay biện minh cho niềm vui lưu giữ kỷ niệm học trò của mình.',
    suggestedPromptIdeas: [
      'Xóa bình luận khiếm nhã và chặn tài khoản (Block) ngay lập tức mà không cần đôi co hay giải thích.',
      'Phản hồi tự tin: "Góc chụp đẹp và hôm đó lớp mình đi chơi siêu vui! Cảm ơn bạn đã quan tâm nhé."',
      'Nhắn tin riêng yêu cầu bạn xóa bình luận khiếm nhã nếu là người quen trong lớp.',
    ],
  },
  {
    id: 'sc-4',
    title: 'Bình Phẩm Ngoại Hình Trong Bữa Cơm Họ Hàng Dịp Lễ',
    context: 'family',
    situation:
      'Trong bữa tiệc gia đình đông đủ họ hàng, một người cô họ nhìn bạn từ đầu đến chân rồi nói to trước mặt mọi người: "Trời ơi sao đợt này đen đúa với mặt nhiều mụn thế con? Con gái con lứa không biết chăm chút sau này ai thèm ngó!" Bố mẹ bạn ngồi bên cạnh tỏ ra lúng túng.',
    quote: '"Trời ơi dạo này đen đúa với mặt nhiều mụn thế cháu? Không lo chăm chút nhan sắc thì sau này khó lấy chồng/vợ đấy nhé!"',
    expertAdvice:
      'Văn hóa thế hệ ở Việt Nam: Người lớn thường bình phẩm với ý nghĩ đó là sự hỏi han, nhưng lại thiếu tinh tế. Hãy dùng kỹ thuật "Thừa nhận nỗ lực học tập + Lịch thiệp chuyển chủ đề" để vừa giữ phép lịch sự vừa không nhận lấy sự tổn thương.',
    suggestedPromptIdeas: [
      'Mỉm cười lễ phép: "Dạ đợt này cháu đang tập trung ôn thi học kỳ nên thức khuya một chút ạ. Sau thi cháu sẽ nghỉ ngơi dưỡng da lại. Cháu mời cô dùng món này ngon lắm ạ."',
      'Sau bữa ăn, tâm sự riêng với bố mẹ để bố mẹ hiểu cảm xúc của mình và đỡ lời giúp mình trong các buổi gặp sau.',
      'Nhắc nhở nhẹ nhàng: "Thời nay năng lực học tập và sự tự lập quan trọng hơn vẻ bề ngoài nhiều cô ạ."',
    ],
  },
  {
    id: 'sc-5',
    title: 'Bị Bạn Thân Vô Tình "Dìm Hàng" Trong Nhóm Chat Lớp',
    context: 'peer_pressure',
    situation:
      'Trong nhóm chat lớp đông thành viên, một người bạn mà bạn khá thân gửi bức ảnh chụp lén góc mặt dìm hàng của bạn trong giờ ngủ trưa kèm caption trêu đùa: "Quái vật ngủ trưa xuất hiện nè mọi người ơi". Các bạn khác bắt đầu thả haha liên tục.',
    quote: '"Quái vật ngủ trưa xuất hiện nè mọi người ơi haha, nhìn cái cằm nọng với tướng ngủ kìa!"',
    expertAdvice:
      'Ranh giới giữa bạn bè thân thiết: Bạn thân không có nghĩa là có quyền mang khuyết điểm thể chất của nhau ra làm trò tiêu khiển trước đám đông. Giao tiếp thẳng thắn và chân thành là cách duy nhất bảo vệ tình bạn bền vững.',
    suggestedPromptIdeas: [
      'Nhắn riêng cho bạn: "Cậu gửi ảnh dìm mình vào nhóm đông người như vậy làm mình rất buồn và khó xử. Cậu gỡ ảnh giúp mình nhé."',
      'Nhắn trực tiếp trong nhóm với thái độ nghiêm túc: "Trò đùa này làm mình thấy không thoải mái, bạn đừng chụp lén rồi đăng lên như vậy nữa nhé."',
      'Tạm tắt thông báo nhóm để giữ tâm trạng bình tĩnh, không vội phản ứng giận dữ hay đăng ảnh trả đũa.',
    ],
  },
];
