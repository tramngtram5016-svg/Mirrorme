export interface VideoScene {
  id: string;
  timestamp: string;
  durationSec: number;
  sceneTitle: string;
  visualTheme: 'mirror' | 'shield' | 'tree' | 'phone' | 'community' | 'breathing';
  narration: string;
  onScreenHeadline: string;
  onScreenBullets: string[];
  dialogue?: {
    speaker: string;
    role: 'student' | 'peer' | 'mentor';
    line: string;
  }[];
  highlightStat?: {
    value: string;
    label: string;
  };
}

export interface VideoQuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface LessonVideo {
  id: string;
  chapterId: string;
  chapterNumber: number;
  title: string;
  subtitle: string;
  duration: string;
  totalSeconds: number;
  category: string;
  thumbnailTheme: 'teal' | 'amber' | 'rose' | 'indigo' | 'emerald' | 'cyan';
  summary: string;
  keyTakeaways: string[];
  scenes: VideoScene[];
  quiz: VideoQuizQuestion[];
}

export const LESSON_VIDEOS: LessonVideo[] = [
  {
    id: 'video-ch1',
    chapterId: 'chapter-1',
    chapterNumber: 1,
    title: 'Giải Mã Bất Mãn Ngoại Hình & Tính Trung Dung Cơ Thể',
    subtitle: 'Vì sao chúng ta hay tự ti khi soi gương và làm sao để trân trọng chức năng sống của cơ thể?',
    duration: '03:20',
    totalSeconds: 40,
    category: 'Chương 1 • Nhận Thức Cơ Thể',
    thumbnailTheme: 'teal',
    summary:
      'Video minh họa cơ chế tâm lý đằng sau sự bất mãn hình ảnh cơ thể ở tuổi dậy thì và hướng dẫn chuyển dịch từ áp lực "phải đẹp hoàn hảo" sang "trân trọng chức năng kỳ diệu của cơ thể" (Tính trung dung cơ thể).',
    keyTakeaways: [
      'Bất mãn ngoại hình ở tuổi THPT là hiện tượng phổ biến do cơ thể đang biến đổi nhanh và tác động từ chuẩn mực xã hội.',
      'Tính trung dung cơ thể giúp bạn bình an với cơ thể bằng cách biết ơn chức năng sống thay vì ép mình phải hoàn hảo.',
      'Mọi thay đổi ngoại hình an toàn phải xuất phát từ việc yêu thương sức khỏe, không phải từ sự chán ghét bản thân.',
    ],
    scenes: [
      {
        id: 'ch1-s1',
        timestamp: '00:00',
        durationSec: 10,
        sceneTitle: 'Bẫy So Sánh Trước Chiếc Gương',
        visualTheme: 'mirror',
        onScreenHeadline: 'Hơn 70% Học Sinh Từng Tự Ti Khi Soi Gương',
        narration:
          'Mỗi buổi sáng thức dậy, khi đứng trước gương, bạn thường nhìn thấy điều gì đầu tiên? Một nốt mụn mới mọc, vóc dáng chưa thon gọn, hay chiều cao chưa như ý? Theo nghiên cứu tại các trường THPT TP.HCM, mong muốn ngoại hình đẹp hơn đạt mức cao nhất 3.39 trên 5.',
        onScreenBullets: [
          'Não bộ tuổi dậy thì rất nhạy cảm với sự thay đổi thể chất',
          'Xu hướng phóng đại khuyết điểm nhỏ (Hiệu ứng kính lúp)',
          'So sánh bản thân với hình mẫu lý tưởng phi thực tế',
        ],
        highlightStat: {
          value: '3.39 / 5.0',
          label: 'Mức độ mong muốn cải thiện ngoại hình ở học sinh THPT',
        },
      },
      {
        id: 'ch1-s2',
        timestamp: '00:50',
        durationSec: 10,
        sceneTitle: 'Áp Lực "Phải Đẹp" Đến Từ Đâu?',
        visualTheme: 'phone',
        onScreenHeadline: 'Nội Tâm Hóa Chuẩn Mực Xã Hội Ảo',
        narration:
          'Chúng ta không tự nhiên ghét cơ thể mình. Sự bất mãn nảy sinh khi ta vô tình biến những tiêu chuẩn khắt khe trên phim ảnh, quảng cáo thành thước đo duy nhất để chấm điểm bản thân.',
        onScreenBullets: [
          'Chuẩn mực "mình hạc xương mai", "da trắng không tì vết" là sản phẩm truyền thông',
          '42,8% học sinh từng muốn ép cân hoặc thay đổi ngoại hình cấp tốc',
          'Nhịn ăn cực đoan hay dùng mỹ phẩm trôi nổi gây hại nghiêm trọng cho sức khỏe',
        ],
        dialogue: [
          {
            speaker: 'Minh Anh (Lớp 10)',
            role: 'student',
            line: 'Sao ai trên mạng nhìn cũng hoàn hảo, còn mình thì đầy khuyết điểm thế này?',
          },
          {
            speaker: 'Thầy/Cô Hướng Dẫn',
            role: 'mentor',
            line: 'Đó là vì em đang lấy hậu trường đời thực của mình để so với bức ảnh đã qua 10 lớp chỉnh sửa của họ đấy!',
          },
        ],
      },
      {
        id: 'ch1-s3',
        timestamp: '01:45',
        durationSec: 10,
        sceneTitle: 'Bước Ngoặt: Tính Trung Dung Cơ Thể',
        visualTheme: 'tree',
        onScreenHeadline: 'Cơ Thể Là Ngôi Nhà Sự Sống, Không Phải Vật Trang Trí',
        narration:
          'Thay vì ép bản thân phải khen từng khuyết điểm mỗi ngày, tâm lý học hiện đại giới thiệu Tính trung dung cơ thể: Trân trọng cơ thể vì những gì nó LÀM ĐƯỢC cho bạn, chứ không phải vì nó TRÔNG NHƯ THẾ NÀO.',
        onScreenBullets: [
          'Đôi chân giúp bạn chạy nhảy, đạp xe đến trường mỗi sáng',
          'Làn da đang nỗ lực bài tiết và bảo vệ cơ thể khỏi vi khuẩn',
          'Trái tim và lá phổi bền bỉ giữ nhịp thở suốt 24 giờ không nghỉ',
        ],
      },
      {
        id: 'ch1-s4',
        timestamp: '02:35',
        durationSec: 10,
        sceneTitle: 'Thực Hành 3 Phút Mỗi Sáng',
        visualTheme: 'breathing',
        onScreenHeadline: 'Bài Tập: Biết Ơn Chức Năng Cơ Thể',
        narration:
          'Ngay từ ngày mai, hãy thử bài tập 3 bước đơn giản: Giảm thời gian soi xét khuyết điểm trước gương, nói lời cảm ơn một bộ phận cơ thể và nuôi dưỡng cơ thể bằng giấc ngủ đủ cùng bữa ăn lành mạnh.',
        onScreenBullets: [
          'Bước 1: Cảm ơn đôi mắt, đôi tay, đôi chân vì ngày học tập năng động',
          'Bước 2: Dừng thói quen phóng to ảnh tự chụp để tìm khuyết điểm',
          'Bước 3: Chăm sóc cơ thể từ lòng biết ơn, không phải từ sự trừng phạt',
        ],
      },
    ],
    quiz: [
      {
        id: 'q1-1',
        question: 'Điểm cốt lõi của tư duy "Tính trung dung cơ thể" trong Chương 1 là gì?',
        options: [
          'Phải luôn tự khen mình đẹp hoàn hảo mọi lúc mọi nơi',
          'Trân trọng cơ thể vì chức năng sống kỳ diệu của nó thay vì chỉ đánh giá qua vẻ bề ngoài',
          'Cố gắng thay đổi ngoại hình cấp tốc để giống thần tượng',
        ],
        correctIndex: 1,
        explanation:
          'Chính xác! Tính trung dung cơ thể giúp chúng ta giải tỏa áp lực ngoại hình bằng cách nhìn nhận cơ thể là người bạn đồng hành giúp ta sống, học tập và trải nghiệm.',
      },
      {
        id: 'q1-2',
        question: 'Nguyên tắc an toàn nhất khi bạn muốn cải thiện sức khỏe và vóc dáng là gì?',
        options: [
          'Bắt đầu từ sự tôn trọng sức khỏe, ngủ đủ giấc, dinh dưỡng khoa học thay vì nhịn ăn cực đoan',
          'Làm theo các thử thách ép cân cấp tốc 3 ngày trên mạng xã hội',
          'Soi gương liên tục mỗi giờ để tự tạo áp lực cho bản thân',
        ],
        correctIndex: 0,
        explanation:
          'Rất chuẩn! Mọi sự thay đổi bền vững đều phải dựa trên nền tảng y khoa và lòng yêu thương cơ thể.',
      },
    ],
  },
  {
    id: 'video-ch2',
    chapterId: 'chapter-2',
    chapterNumber: 2,
    title: 'Quy Tắc "Tấm Gương & Tấm Kính" Khi Bị Bình Phẩm Ngoại Hình',
    subtitle: 'Cách thiết lập ranh giới văn minh, dứt khoát trước những lời trêu chọc kém duyên',
    duration: '03:45',
    totalSeconds: 40,
    category: 'Chương 2 • Kỹ Năng Ứng Phó',
    thumbnailTheme: 'amber',
    summary:
      'Video tình huống tái hiện các kiểu bình phẩm ngoại hình thường gặp ở trường học và hướng dẫn 4 kịch bản đối đáp quyết đoán và văn minh giúp bạn bảo vệ năng lượng tâm lý.',
    keyTakeaways: [
      'Lời chê bai ngoại hình là "Tấm gương" phản chiếu sự bất an của người nói, không phải "Tấm kính" phản ánh giá trị của bạn.',
      'Nỗi lo bị đánh giá tiếp theo (TB 2.61) thường kéo dài hơn lời trêu chọc ban đầu — cần ngắt dòng suy nghĩ lặp lại.',
      'Sử dụng kỹ thuật hỏi ngược điềm tĩnh và thái độ trung tính (Hòn đá xám) để đặt ranh giới văn minh mà không cần cãi vã.',
    ],
    scenes: [
      {
        id: 'ch2-s1',
        timestamp: '00:00',
        durationSec: 10,
        sceneTitle: 'Nhận Diện Những Lời Trêu "Núp Bóng Đùa Vui"',
        visualTheme: 'shield',
        onScreenHeadline: 'Khi Lời Đùa Vô Tâm Để Lại Dư Chấn Dài Lâu',
        narration:
          'Ở hành lang lớp học hay trong bữa cơm gia đình, không ít lần chúng ta nghe những câu như: "Dạo này tròn thế!", "Mặt nhiều mụn vậy?". Dù người nói bảo "Chỉ đùa thôi mà", nhưng dư chấn lo âu trong lòng người nghe lại kéo dài nhiều tuần.',
        onScreenBullets: [
          'Trêu chọc núp bóng hài hước: "Đùa tí làm gì căng!"',
          'Lời khen độc hại núp bóng châm chọc',
          'Dư chấn tâm lý: Lo lắng bị soi xét (Điểm TB 2.61/5.0)',
        ],
        highlightStat: {
          value: '2.61 / 5.0',
          label: 'Điểm lo âu kéo dài sau khi trải qua bình phẩm ngoại hình',
        },
      },
      {
        id: 'ch2-s2',
        timestamp: '00:55',
        durationSec: 10,
        sceneTitle: 'Nguyên Lý Tâm Lý: Tấm Gương Và Tấm Kính',
        visualTheme: 'mirror',
        onScreenHeadline: 'Lời Chê Bai Phản Chiếu Người Nói, Không Định Nghĩa Bạn',
        narration:
          'Hãy tưởng tượng lời bình phẩm của ai đó là một TẤM GƯƠNG soi chính sự thiếu tinh tế và bất an của họ, chứ không phải TẤM KÍNH nhìn thấu giá trị của bạn. Bạn hoàn toàn có quyền từ chối nhận "món quà độc hại" đó.',
        onScreenBullets: [
          'Người tự tin và hạnh phúc không bao giờ tìm niềm vui bằng cách hạ thấp ngoại hình người khác',
          'Tách biệt "nhận xét chủ quan của họ" khỏi "giá trị thật của mình"',
          'Kích hoạt tấm khiên tâm lý ngay trong 3 giây đầu tiên',
        ],
      },
      {
        id: 'ch2-s3',
        timestamp: '01:50',
        durationSec: 10,
        sceneTitle: 'Thực Chiến Đối Đáp: Hỏi Ngược Điềm Tĩnh & Đặt Ranh Giới',
        visualTheme: 'shield',
        onScreenHeadline: 'Bình Tĩnh • Quyết Đoán • Không Đôi Co',
        narration:
          'Xem cách bạn Nam phản hồi khi bị bạn cùng lớp trêu chọc ngoại hình. Không nổi nóng chửi lại, cũng không cúi đầu tủi thân, Nam dùng phương pháp Đặt ranh giới trực diện.',
        onScreenBullets: [
          'Kỹ thuật hỏi ngược điềm tĩnh: "Cậu có ý gì khi nói câu đó vậy?"',
          'Đặt ranh giới rõ ràng: "Mình không thoải mái khi mang ngoại hình ra đùa. Đổi chủ đề nhé."',
          'Kỹ thuật thái độ trung tính (Hòn đá xám): "Ừ, mình biết rồi" rồi thản nhiên làm việc tiếp',
        ],
        dialogue: [
          {
            speaker: 'Bạn cùng lớp',
            role: 'peer',
            line: 'Ê dạo này ăn gì mà mặt tròn xoe như cái mâm thế haha!',
          },
          {
            speaker: 'Nam (Áp dụng Cẩm nang)',
            role: 'student',
            line: 'Mình đang tập trung giữ sức khỏe để ôn thi. Mình không thích đùa về ngoại hình đâu, tụi mình bàn tiếp bài tập nhóm đi.',
          },
        ],
      },
      {
        id: 'ch2-s4',
        timestamp: '02:50',
        durationSec: 10,
        sceneTitle: 'Khi Nào Cần Tìm Sự Hỗ Trợ Từ Thầy Cô?',
        visualTheme: 'community',
        onScreenHeadline: 'Không Khoan Nhượng Với Bắt Nạt Học Đường & Công Kích Trên Mạng',
        narration:
          'Nếu hành vi chế giễu lặp đi lặp lại, cắt ghép ảnh dìm hàng lên mạng xã hội hoặc lập nhóm nói xấu, đó không còn là trêu đùa mà là bắt nạt. Hãy chụp màn hình bằng chứng và báo ngay cho Giáo viên chủ nhiệm hoặc Phòng Tâm lý học đường.',
        onScreenBullets: [
          'Lưu giữ bằng chứng tin nhắn, hình ảnh bình luận ác ý',
          'Chia sẻ ngay với thầy cô tư vấn tâm lý hoặc cha mẹ',
          'Tìm kiếm sự trợ giúp là hành động dũng cảm và thông minh',
        ],
      },
    ],
    quiz: [
      {
        id: 'q2-1',
        question: 'Theo Quy tắc "Tấm Gương & Tấm Kính", lời chê bai ngoại hình từ người khác thực chất phản ánh điều gì?',
        options: [
          'Phản ánh chính xác giá trị con người bạn',
          'Là tấm gương phản chiếu sự thiếu tế nhị hoặc bất an của chính người nói',
          'Chứng tỏ bạn phải thay đổi bản thân ngay lập tức để chiều lòng họ',
        ],
        correctIndex: 1,
        explanation:
          'Đúng vậy! Cách một người phán xét ngoại hình người khác nói lên văn hóa ứng xử của họ chứ không phải giá trị của bạn.',
      },
      {
        id: 'q2-2',
        question: 'Câu trả lời nào sau đây thể hiện phong cách "Quyết đoán & Văn minh" khi bị bạn bè trêu chọc?',
        options: [
          'Chửi mắng lại thật nặng nề để trả đũa',
          'Im lặng chịu đựng rồi về nhà khóc một mình',
          '"Mình không thoải mái khi ngoại hình bị đem ra đùa như vậy. Chúng mình đổi chủ đề nhé."',
        ],
        correctIndex: 2,
        explanation:
          'Xuất sắc! Phản hồi quyết đoán giúp bạn giữ vững sự tôn nghiêm, đặt ranh giới rõ ràng mà vẫn lịch sự.',
      },
    ],
  },
  {
    id: 'video-ch3',
    chapterId: 'chapter-3',
    chapterNumber: 3,
    title: 'Khám Phá Khoa Học: Ngoại Hình Không Quyết Định Lòng Tự Trọng!',
    subtitle: 'Xây dựng "Cây Giá Trị Bản Thân 5 Trụ Cột" vững vàng trước mọi biến động',
    duration: '03:30',
    totalSeconds: 40,
    category: 'Chương 3 • Lòng Tự Trọng',
    thumbnailTheme: 'rose',
    summary:
      'Video trực quan hóa phát hiện khoa học quan trọng nhất từ khảo sát 607 học sinh THPT: Sự bất mãn ngoại hình không làm suy giảm lòng tự trọng nếu bạn sở hữu 5 trụ cột giá trị nội tại vững chắc.',
    keyTakeaways: [
      'Phân tích thống kê trên 607 học sinh cho thấy tương quan giữa Bất mãn cơ thể và Lòng tự trọng là r = 0.061 (p = 0.133 > 0.05) — không có ý nghĩa thống kê.',
      'Bạn hoàn toàn có thể chưa hài lòng một vài nét trên cơ thể nhưng vẫn giữ lòng tự trọng cao!',
      '5 Trụ cột cốt lõi: Trí tuệ & Sáng tạo, Nhân cách tử tế, Sự kiên trì, Kết nối yêu thương và Ý thức tự tôn trọng.',
    ],
    scenes: [
      {
        id: 'ch3-s1',
        timestamp: '00:00',
        durationSec: 10,
        sceneTitle: 'Phá Vỡ Lầm Tưởng Phổ Biến',
        visualTheme: 'tree',
        onScreenHeadline: 'Sự Thật Bất Ngờ Từ Khảo Sát 607 Học Sinh THPT',
        narration:
          'Nhiều người nghĩ rằng: Hễ ai tự ti về ngoại hình thì chắc chắn người đó sẽ đánh mất lòng tự trọng. Nhưng dữ liệu nghiên cứu thực tế tại TP.HCM đã chứng minh điều ngược lại!',
        onScreenBullets: [
          'Hệ số tương quan r = 0.061 (p = 0.133 > 0.05): Không có mối liên hệ bắt buộc',
          'Học sinh THPT đánh giá giá trị bản thân dựa trên năng lực và phẩm chất nhiều hơn vẻ ngoài',
          'Ngoại hình chỉ là 1 căn phòng nhỏ trong tòa lâu đài giá trị của bạn',
        ],
        highlightStat: {
          value: 'r = 0.061',
          label: 'Bất mãn cơ thể KHÔNG quyết định lòng tự trọng của học sinh',
        },
      },
      {
        id: 'ch3-s2',
        timestamp: '00:55',
        durationSec: 10,
        sceneTitle: 'Mô Hình 5 Trụ Cột Của Cây Giá Trị Bản Thân',
        visualTheme: 'tree',
        onScreenHeadline: 'Đừng Đặt Cả Gia Tài Tự Tin Vào Chiếc Giỏ Ngoại Hình',
        narration:
          'Hãy hình dung lòng tự trọng của bạn như một cái cây cổ thụ có 5 bộ rễ sâu. Khi 5 bộ rễ này khỏe mạnh, không một cơn gió chê bai nào có thể làm cây gục ngã.',
        onScreenBullets: [
          '1. Năng lực học tập & Sáng tạo  •  2. Nhân cách & Sự tử tế (TB 3.42)',
          '3. Mục tiêu & Sự kiên trì vượt khó  •  4. Mối quan hệ gắn kết chân thành',
          '5. Ý thức chủ động tôn trọng chính mình (Đạt cao nhất: TB 3.60/5.0)',
        ],
      },
      {
        id: 'ch3-s3',
        timestamp: '01:50',
        durationSec: 10,
        sceneTitle: 'Câu Chuyện Của Lan: Tỏa Sáng Từ Giá Trị Thật',
        visualTheme: 'community',
        onScreenHeadline: 'Sự Tự Tin Đích Thực Đến Từ Nội Lực',
        narration:
          'Lan từng ngại ngùng vì chiều cao khiêm tốn và làn da ngăm. Nhưng khi tham gia CLB Tranh biện và hỗ trợ bạn bè học tập, Lan nhận ra mọi người yêu quý mình vì sự thông minh, ấm áp và nụ cười rạng rỡ.',
        onScreenBullets: [
          'Chuyển tâm điểm từ "Mình trông thế nào?" sang "Mình đóng góp được gì?"',
          'Ghi nhận những nỗ lực nhỏ đáng tự hào mỗi tối trước khi đi ngủ',
          'Nuôi dưỡng niềm tự hào về sự nỗ lực của bản thân',
        ],
        dialogue: [
          {
            speaker: 'Lan (Lớp 11)',
            role: 'student',
            line: 'Mình nhận ra khi mình say mê thuyết trình và giúp đỡ bạn bè, chẳng ai còn bận tâm mình cao bao nhiêu nữa!',
          },
          {
            speaker: 'Thầy/Cô Hướng Dẫn',
            role: 'mentor',
            line: 'Chính xác! Ánh sáng từ trí tuệ và lòng tốt luôn có sức hút bền vững nhất.',
          },
        ],
      },
      {
        id: 'ch3-s4',
        timestamp: '02:45',
        durationSec: 10,
        sceneTitle: 'Thực Hành: Vẽ Bản Đồ Giá Trị Của Riêng Bạn',
        visualTheme: 'tree',
        onScreenHeadline: 'Tôi Luôn Học Cách Tôn Trọng Bản Thân Hơn Mỗi Ngày',
        narration:
          'Hôm nay, hãy lấy một tờ giấy nhỏ và viết xuống 3 phẩm chất không liên quan đến ngoại hình mà bạn yêu quý nhất ở bản thân. Đó chính là gốc rễ tạo nên bản lĩnh của bạn.',
        onScreenBullets: [
          'Viết 3 phẩm chất tốt đẹp của bạn (VD: Biết lắng nghe, kiên trì, hài hước)',
          'Ghi nhận 1 nỗ lực nhỏ bạn đã hoàn thành trong hôm nay',
          'Nhắc nhở bản thân: Giá trị của mình là đa diện và duy nhất',
        ],
      },
    ],
    quiz: [
      {
        id: 'q3-1',
        question: 'Kết quả nghiên cứu thống kê giữa Bất mãn hình ảnh cơ thể (CNVCT) và Lòng tự trọng (LTT) cho biết điều gì?',
        options: [
          'Ngoại hình quyết định 100% lòng tự trọng của học sinh',
          'Không có tương quan có ý nghĩa thống kê (r = 0.061) — học sinh vẫn có lòng tự trọng cao nhờ các trụ cột phẩm chất và năng lực',
          'Chỉ những người hoàn hảo về ngoại hình mới tự tin',
        ],
        correctIndex: 1,
        explanation:
          'Chính xác! Đây là phát hiện khoa học rất ý nghĩa giúp học sinh hiểu rằng lòng tự trọng nằm ở phẩm chất, trí tuệ và ý thức tự tôn trọng.',
      },
    ],
  },
  {
    id: 'video-ch4',
    chapterId: 'chapter-4',
    chapterNumber: 4,
    title: 'Vệ Sinh Tâm Lý Số & Giải Mã Bẫy Bộ Lọc Ảo Ảnh',
    subtitle: 'Đừng đem hậu trường đời thực đi so sánh với thước phim đã qua chỉnh sửa trên mạng',
    duration: '03:15',
    totalSeconds: 40,
    category: 'Chương 4 • Mạng Xã Hội Tỉnh Thức',
    thumbnailTheme: 'indigo',
    summary:
      'Video bóc tách cách thuật toán mạng xã hội và các bộ lọc làm đẹp tạo ra "Ảo ảnh hoàn hảo", đồng thời hướng dẫn thử thách 7 ngày thanh lọc nguồn cấp tin để bảo vệ sức khỏe tinh thần.',
    keyTakeaways: [
      '53,1% học sinh tiếp cận thông tin qua mạng xã hội — nơi thuật toán ưu tiên hiển thị những hình ảnh đã qua chỉnh sửa kỹ lưỡng.',
      'Hiểu rõ ảo ảnh từ cuốn phim hào nhoáng đã qua chọn lọc để không rơi vào bẫy tự ti khi lướt mạng.',
      'Chủ động Hủy theo dõi / Ẩn các tài khoản gây áp lực ngoại hình và thiết lập 60 phút không màn hình trước giờ ngủ.',
    ],
    scenes: [
      {
        id: 'ch4-s1',
        timestamp: '00:00',
        durationSec: 10,
        sceneTitle: 'Sự Thật Phía Sau Những Bức Ảnh Triệu Tim',
        visualTheme: 'phone',
        onScreenHeadline: 'Hậu Trường Đời Thực vs. Cuốn Phim Đã Qua Bộ Lọc',
        narration:
          'Một bức ảnh lung linh trên mạng xã hội thường là kết quả của 50 lần bấm máy, góc chiếu sáng hoàn hảo và 3 lớp ứng dụng chỉnh sửa. Thế nhưng khi lướt xem, não bộ chúng ta lại lầm tưởng đó là vẻ đẹp tự nhiên 24/7 của người khác.',
        onScreenBullets: [
          '53,1% học sinh THPT tiếp nhận chuẩn mực ngoại hình qua mạng xã hội',
          'Bộ lọc làm mịn da, bóp gọn mặt tạo ra tiêu chuẩn sinh học bất khả thi',
          'Đếm lượt Thích dễ biến tâm trạng bạn thành con tin của mạng ảo',
        ],
        highlightStat: {
          value: '53.1%',
          label: 'Tỷ lệ học sinh tiếp cận thông tin qua kênh Mạng xã hội',
        },
      },
      {
        id: 'ch4-s2',
        timestamp: '00:50',
        durationSec: 10,
        sceneTitle: 'Thuật Toán Dẫn Dắt Sự Tự Ti Như Thế Nào?',
        visualTheme: 'phone',
        onScreenHeadline: 'Vòng Xoáy Thuật Toán & Quảng Cáo Làm Đẹp Cấp Tốc',
        narration:
          'Chỉ cần bạn dừng lại 5 giây ở một video "biến hình" hay quảng cáo giảm cân, thuật toán sẽ lập tức phủ kín bảng tin của bạn bằng hàng trăm video tương tự, khiến bạn ngỡ rằng cả thế giới đều hoàn hảo trừ mình.',
        onScreenBullets: [
          'Thuật toán tối ưu hóa thời gian giữ chân, không tối ưu hóa hạnh phúc của bạn',
          'Các trào lưu "eo A4", "cơ bụng số 11" đánh vào tâm lý sợ khác biệt',
          'Nhận diện cơ chế này giúp bạn lấy lại quyền làm chủ tâm trí',
        ],
      },
      {
        id: 'ch4-s3',
        timestamp: '01:45',
        durationSec: 10,
        sceneTitle: 'Chiến Lược Thanh Lọc Không Gian Số',
        visualTheme: 'shield',
        onScreenHeadline: 'Bạn Là Người Quyết Định Thuật Toán Của Chính Mình',
        narration:
          'Hãy biến mạng xã hội thành không gian truyền cảm hứng học tập và sáng tạo. Đừng ngần ngại nhấn Hủy theo dõi hoặc Ẩn bất kỳ tài khoản nào khiến bạn cảm thấy mệt mỏi, tự ti sau khi xem.',
        onScreenBullets: [
          'Dũng cảm Hủy theo dõi các trang cổ xúy chuẩn mực ngoại hình độc hại',
          'Theo dõi các kênh khoa học, nghệ thuật, thể thao, kỹ năng sống',
          'Nhấn "Không quan tâm" với các quảng cáo thuốc giảm cân, kem trộn',
        ],
      },
      {
        id: 'ch4-s4',
        timestamp: '02:35',
        durationSec: 10,
        sceneTitle: 'Thử Thách 7 Ngày Lướt Mạng Có Chánh Niệm',
        visualTheme: 'breathing',
        onScreenHeadline: 'Tắt Màn Hình Ảo • Bật Kết Nối Thật',
        narration:
          'Hãy bắt đầu thử thách nhỏ tuần này: Dành 60 phút trước khi đi ngủ hoàn toàn không điện thoại, tự tin lưu giữ những khoảnh khắc mộc mạc cùng bạn bè mà không cần bóp méo khuôn mặt qua ứng dụng.',
        onScreenBullets: [
          'Ngày 1-2: Dọn dẹp danh sách theo dõi trên các trang mạng xã hội',
          'Ngày 3-4: Trân trọng những bức ảnh kỷ niệm tự nhiên, chân thật',
          'Ngày 5-7: Nghỉ ngơi mắt và tâm trí 60 phút trước giấc ngủ đêm',
        ],
      },
    ],
    quiz: [
      {
        id: 'q4-1',
        question: 'Khi lướt mạng xã hội và thấy mình bắt đầu tự ti vì so sánh với ảnh của người khác, bạn nên làm gì?',
        options: [
          'Tải thêm nhiều ứng dụng chỉnh ảnh để bóp mặt giống họ',
          'Nhớ rằng mạng xã hội chỉ là cuốn phim hào nhoáng đã qua chọn lọc và chủ động thanh lọc bảng tin (Hủy theo dõi và nghỉ ngơi)',
          'Tiếp tục lướt xem thêm hàng giờ trong đêm',
        ],
        correctIndex: 1,
        explanation:
          'Rất chính xác! Tỉnh thức trước ảo ảnh mạng xã hội và chủ động dọn dẹp nguồn cấp tin là kỹ năng cần thiết trong kỷ nguyên số.',
      },
    ],
  },
  {
    id: 'video-ch5',
    chapterId: 'chapter-5',
    chapterNumber: 5,
    title: 'Quy Tắc "5 Giây Vàng" & Trở Thành Người Bạn Đồng Hành Tử Tế',
    subtitle: 'Xây dựng lớp học an toàn, nơi không ai bị tổn thương bởi những lời đùa ngoại hình',
    duration: '03:10',
    totalSeconds: 40,
    category: 'Chương 5 • Văn Hóa Học Đường',
    thumbnailTheme: 'emerald',
    summary:
      'Video minh họa Quy tắc 5 Giây Vàng trong giao tiếp học đường và hướng dẫn 3 bước trở thành "Người bạn bảo vệ tích cực" khi chứng kiến bạn bè bị trêu chọc ngoại hình.',
    keyTakeaways: [
      'Quy tắc 5 Giây Vàng: Chỉ góp ý về ngoại hình nếu người đối diện có thể chỉnh sửa nó trong vòng 5 giây (như cổ áo bị lệch, dây giày tuột).',
      'Không bao giờ lấy cân nặng, chiều cao, làn da hay đặc điểm cơ thể của bạn bè làm biệt danh trêu đùa.',
      'Trở thành người bạn bảo vệ tích cực: Không cười hùa, khéo léo đánh lạc hướng và động viên bạn sau giờ học.',
    ],
    scenes: [
      {
        id: 'ch5-s1',
        timestamp: '00:00',
        durationSec: 10,
        sceneTitle: 'Ranh Giới Giữa Vui Đùa Và Tổn Thương',
        visualTheme: 'community',
        onScreenHeadline: 'Niềm Vui Thật Sự Khi Tất Cả Cùng Cười',
        narration:
          'Một câu đùa chỉ thực sự vui khi người được nhắc đến cũng cảm thấy thoải mái. Nếu cả nhóm cùng cười mà có một người đang cúi mặt ngượng ngùng, đó không phải là hài hước — đó là sự tổn thương.',
        onScreenBullets: [
          'Cảm xúc buồn bã khi bị bình phẩm đạt TB 2.59/5.0 trong khảo sát',
          'Đặt biệt danh theo khuyết điểm cơ thể làm xói mòn sự gắn kết lớp học',
          'Sự tử tế bắt đầu từ việc cẩn trọng trong từng lời nói hàng ngày',
        ],
        highlightStat: {
          value: '5 Giây',
          label: 'Quy tắc vàng trước khi nhận xét về vẻ bề ngoài của bất kỳ ai',
        },
      },
      {
        id: 'ch5-s2',
        timestamp: '00:50',
        durationSec: 10,
        sceneTitle: 'Quy Tắc 5 Giây Vàng Trong Giao Tiếp',
        visualTheme: 'shield',
        onScreenHeadline: 'Không Đổi Được Trong 5 Giây -> Tuyệt Đối Không Nói!',
        narration:
          'Trước khi nhận xét ngoại hình ai đó, hãy tự hỏi: Họ có sửa được điều này trong 5 giây không? Dây giày tuột, cổ áo lệch, vết mực trên má — hãy nhắc nhỏ tinh tế. Còn chiều cao, cân nặng, mụn, màu da — tuyệt đối không mang ra nhận xét!',
        onScreenBullets: [
          'NÊN NHẮC TINH TẾ (< 5 giây): Dây giày tuột, áo dính bẩn, tóc rối nhẹ',
          'KHÔNG BAO GIỜ CHÊ (> 5 giây): Cân nặng, vóc dáng, làn da, mụn, khuôn mặt',
          'Thay lời phán xét ngoại hình bằng lời khen ngợi nỗ lực và tính cách',
        ],
      },
      {
        id: 'ch5-s3',
        timestamp: '01:45',
        durationSec: 10,
        sceneTitle: '3 Bước Trở Thành "Người Bạn Bảo Vệ Tích Cực"',
        visualTheme: 'community',
        onScreenHeadline: 'Đừng Im Lặng Cười Hùa Khi Bạn Bè Bị Chế Giễu',
        narration:
          'Khi thấy một người bạn trong lớp bị trêu chọc ngoại hình, bạn không cần phải cãi nhau căng thẳng. Chỉ cần 3 hành động nhỏ cũng đủ giải cứu bạn mình khỏi tình huống khó xử.',
        onScreenBullets: [
          'Bước 1: Không cười hùa hay bấm thích bình luận trêu chọc',
          'Bước 2: Đánh lạc hướng tự nhiên ("Ê bàn tiếp vụ tiết mục văn nghệ lớp đi!")',
          'Bước 3: Hỏi thăm và khẳng định giá trị của bạn sau khi đám đông tản ra',
        ],
        dialogue: [
          {
            speaker: 'Hoàng (Người bạn bảo vệ)',
            role: 'student',
            line: 'Thôi chuyện ngoại hình có gì đâu mà bàn, tụi mình xem lại đề cương Toán chiều nay đi mọi người!',
          },
          {
            speaker: 'Bạn bị trêu',
            role: 'student',
            line: 'Cảm ơn Hoàng nhé, nhờ câu nói của cậu mà mình đỡ bối rối hẳn.',
          },
        ],
      },
      {
        id: 'ch5-s4',
        timestamp: '02:35',
        durationSec: 10,
        sceneTitle: 'Lan Tỏa Văn Hóa Lớp Học Tôn Trọng',
        visualTheme: 'tree',
        onScreenHeadline: 'Mỗi Học Sinh Là Một Đại Sứ Tâm Lý Tích Cực',
        narration:
          'Khi mỗi thành viên trong lớp cùng thực hành Quy tắc 5 Giây và tôn trọng sự đa dạng hình thể, lớp học sẽ trở thành nơi an toàn nhất để tất cả cùng tự tin phát triển.',
        onScreenBullets: [
          'Tôn trọng sự khác biệt tự nhiên của mỗi cá nhân',
          'Khen ngợi sự cố gắng, lòng tốt và tinh thần đồng đội',
          'Cùng xây dựng môi trường THPT văn minh, giàu lòng nhân ái',
        ],
      },
    ],
    quiz: [
      {
        id: 'q5-1',
        question: 'Theo "Quy tắc 5 Giây Vàng", điều nào sau đây bạn KHÔNG NÊN nhận xét về người khác?',
        options: [
          'Nhắc nhỏ bạn khi dây balo của bạn bị tuột',
          'Chê bai cân nặng, chiều cao hoặc làn da đang bị mụn của bạn',
          'Báo cho bạn biết cổ áo đồng phục đang bị gập',
        ],
        correctIndex: 1,
        explanation:
          'Chính xác! Cân nặng, chiều cao hay mụn là những điều không thể thay đổi trong 5 giây, việc nhận xét chỉ gây tổn thương không đáng có.',
      },
    ],
  },
  {
    id: 'video-practice-6',
    chapterId: 'chapter-2',
    chapterNumber: 6,
    title: 'Thực Hành Nhanh: Thở 4-7-8 & Sơ Cứu Cảm Xúc Khi Bị Tổn Thương',
    subtitle: 'Hướng dẫn trực quan kỹ thuật điều hòa hệ thần kinh trong 60 giây khi vừa gặp lời bình phẩm',
    duration: '02:40',
    totalSeconds: 32,
    category: 'Thực Hành • Sơ Cứu Cảm Xúc',
    thumbnailTheme: 'cyan',
    summary:
      'Video hướng dẫn thực hành trực tiếp nhịp thở 4-7-8 kết hợp lòng tự trắc ẩn giúp làm dịu nhịp tim và lấy lại sự bình tĩnh ngay sau khi gặp tình huống căng thẳng.',
    keyTakeaways: [
      'Nhịp thở 4-7-8 kích hoạt hệ thần kinh phó giao cảm, giúp giảm nhanh phản ứng căng thẳng.',
      'Kết hợp câu tự nhủ tích cực để tách bản thân khỏi lời phán xét bên ngoài.',
      'Có thể áp dụng kín đáo ngay tại chỗ ngồi trong lớp hoặc trước khi bước vào phòng thi.',
    ],
    scenes: [
      {
        id: 'ch6-s1',
        timestamp: '00:00',
        durationSec: 8,
        sceneTitle: 'Khi Tim Đập Nhanh Vì Một Lời Nói Ác Ý',
        visualTheme: 'breathing',
        onScreenHeadline: 'Đừng Phản Ứng Ngay Khi Cảm Xúc Đang Dâng Trào',
        narration:
          'Khi vừa nghe một lời chê bai bất ngờ, hạch hạnh nhân trong não bộ sẽ báo động khiến tim đập nhanh, mặt nóng bừng. Khoảnh khắc đó, việc quan trọng nhất là làm dịu cơ thể trước khi trả lời.',
        onScreenBullets: [
          'Nhận diện cảm xúc: "Mình đang buồn và tức giận, điều đó hoàn toàn tự nhiên"',
          'Tạm dừng 3 giây trước khi phản ứng',
          'Đặt bàn chân chạm sàn vững chãi để neo giữ thực tại',
        ],
      },
      {
        id: 'ch6-s2',
        timestamp: '00:40',
        durationSec: 12,
        sceneTitle: 'Thực Hành Cùng Video: Nhịp Thở 4 - 7 - 8',
        visualTheme: 'breathing',
        onScreenHeadline: 'Hít Vào 4 Giây • Giữ Hơi 7 Giây • Thở Ra 8 Giây',
        narration:
          'Hãy thả lỏng hai vai và làm theo nhịp đếm trên màn hình: Hít vào nhẹ nhàng bằng mũi trong 4 giây... Giữ hơi thở trong 7 giây... Và thở ra từ từ qua miệng trong 8 giây như đang thổi nhẹ một ngọn nến.',
        onScreenBullets: [
          '4 giây Hít vào: Đón nhận nguồn oxy tươi mới',
          '7 giây Giữ hơi: Để oxy lan tỏa và làm dịu nhịp tim',
          '8 giây Thở ra: Buông bỏ sự căng thẳng và lời nói tiêu cực ra ngoài',
        ],
        highlightStat: {
          value: '4 - 7 - 8',
          label: 'Công thức nhịp thở vàng giúp làm dịu hệ thần kinh tức thì',
        },
      },
      {
        id: 'ch6-s3',
        timestamp: '01:45',
        durationSec: 12,
        sceneTitle: 'Câu Tự Thoại Chữa Lành Nội Tâm',
        visualTheme: 'tree',
        onScreenHeadline: '"Giá Trị Của Mình Do Chính Mình Kiến Tạo"',
        narration:
          'Sau 3 chu kỳ thở sâu, hãy đặt tay lên ngực và thầm nhủ: Cảm xúc của mình lúc này là hợp lý, nhưng lời phán xét kia không định nghĩa con người mình. Mình an toàn và mình xứng đáng được tôn trọng.',
        onScreenBullets: [
          'Lòng tự trắc ẩn: Dịu dàng với bản thân như với người bạn thân nhất',
          'Chuyển hướng sự chú ý sang một hoạt động tích cực hoặc trò chuyện với bạn bè',
          'Sử dụng mục Góc Lắng Nghe & Đồng Hành trong ứng dụng bất cứ khi nào bạn cần giải tỏa',
        ],
      },
    ],
    quiz: [
      {
        id: 'q6-1',
        question: 'Tác dụng sinh học chính của kỹ thuật thở 4-7-8 khi bạn đang căng thẳng là gì?',
        options: [
          'Kích hoạt hệ thần kinh phó giao cảm, làm chậm nhịp tim và đưa tâm trí về trạng thái bình tĩnh',
          'Giúp bạn nói nhanh hơn để tranh cãi',
          'Làm tăng sự căng thẳng của cơ bắp',
        ],
        correctIndex: 0,
        explanation:
          'Hoàn toàn chính xác! Pha thở ra kéo dài 8 giây là chìa khóa sinh học giúp hệ thần kinh của bạn thư giãn nhanh chóng.',
      },
    ],
  },
];
