import React, { useState, useEffect, useRef } from 'react';
import { LESSON_VIDEOS, LessonVideo, VideoScene } from '../data/lessonVideos';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Subtitles,
  CheckCircle2,
  BookOpen,
  Sparkles,
  Award,
  MessageSquare,
  Send,
  Loader2,
  Clock,
  ChevronRight,
  HelpCircle,
  Film,
  Tv,
  LayoutGrid,
  Heart,
  Smile,
  Shield,
  Zap,
  Wind,
} from 'lucide-react';

interface LessonVideosViewProps {
  initialVideoId?: string;
  onOpenHandbookChapter?: (chapterId: string) => void;
}

export const LessonVideosView: React.FC<LessonVideosViewProps> = ({
  initialVideoId,
  onOpenHandbookChapter,
}) => {
  const [selectedVideoId, setSelectedVideoId] = useState<string>(
    initialVideoId || LESSON_VIDEOS[0].id
  );
  const [currentSceneIndex, setCurrentSceneIndex] = useState<number>(0);
  const [sceneElapsed, setSceneElapsed] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [showCaptions, setShowCaptions] = useState<boolean>(true);
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'cartoon_player' | 'comic_strip'>('cartoon_player');
  const [watchedVideos, setWatchedVideos] = useState<string[]>([]);
  const [activeBottomTab, setActiveBottomTab] = useState<'timestamps' | 'quiz' | 'ai'>('timestamps');

  // Interactive filter slider in scene 4
  const [filterSliderVal, setFilterSliderVal] = useState<number>(50);

  // Quiz state
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});

  // AI Q&A state
  const [aiQuestion, setAiQuestion] = useState<string>('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState<boolean>(false);

  const timerRef = useRef<number | null>(null);

  const currentVideo: LessonVideo =
    LESSON_VIDEOS.find((v) => v.id === selectedVideoId) || LESSON_VIDEOS[0];
  const currentScene: VideoScene =
    currentVideo.scenes[currentSceneIndex] || currentVideo.scenes[0];

  // Sync when initialVideoId changes
  useEffect(() => {
    if (initialVideoId && LESSON_VIDEOS.some((v) => v.id === initialVideoId)) {
      setSelectedVideoId(initialVideoId);
      setCurrentSceneIndex(0);
      setSceneElapsed(0);
      setIsPlaying(true);
    }
  }, [initialVideoId]);

  // Speech synthesis voiceover
  const speakText = (text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    if (!voiceEnabled) return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'vi-VN';
    utterance.rate = playbackSpeed;
    const voices = window.speechSynthesis.getVoices();
    const viVoice = voices.find((v) => v.lang.toLowerCase().includes('vi'));
    if (viVoice) utterance.voice = viVoice;
    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    if (isPlaying && voiceEnabled) {
      speakText(currentScene.narration);
    } else if (!isPlaying && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [currentSceneIndex, selectedVideoId, isPlaying, voiceEnabled]);

  // Playback timer
  useEffect(() => {
    if (!isPlaying) {
      if (timerRef.current) window.clearInterval(timerRef.current);
      return;
    }

    const intervalMs = 100;
    timerRef.current = window.setInterval(() => {
      setSceneElapsed((prev) => {
        const nextElapsed = prev + (intervalMs / 1000) * playbackSpeed;
        if (nextElapsed >= currentScene.durationSec) {
          if (currentSceneIndex < currentVideo.scenes.length - 1) {
            setCurrentSceneIndex((idx) => idx + 1);
            return 0;
          } else {
            setIsPlaying(false);
            setWatchedVideos((prevWatched) =>
              prevWatched.includes(currentVideo.id)
                ? prevWatched
                : [...prevWatched, currentVideo.id]
            );
            return currentScene.durationSec;
          }
        }
        return nextElapsed;
      });
    }, intervalMs);

    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, [isPlaying, currentSceneIndex, currentScene.durationSec, currentVideo, playbackSpeed]);

  const handleSelectVideo = (video: LessonVideo) => {
    setSelectedVideoId(video.id);
    setCurrentSceneIndex(0);
    setSceneElapsed(0);
    setIsPlaying(true);
    setAiResponse(null);
    setAiQuestion('');
  };

  const handleTogglePlay = () => {
    if (
      !isPlaying &&
      sceneElapsed >= currentScene.durationSec &&
      currentSceneIndex === currentVideo.scenes.length - 1
    ) {
      setCurrentSceneIndex(0);
      setSceneElapsed(0);
    }
    setIsPlaying((prev) => !prev);
  };

  const handleRestart = () => {
    setCurrentSceneIndex(0);
    setSceneElapsed(0);
    setIsPlaying(true);
  };

  const handlePrevScene = () => {
    if (currentSceneIndex > 0) {
      setCurrentSceneIndex((idx) => idx - 1);
      setSceneElapsed(0);
    } else {
      setSceneElapsed(0);
    }
  };

  const handleNextScene = () => {
    if (currentSceneIndex < currentVideo.scenes.length - 1) {
      setCurrentSceneIndex((idx) => idx + 1);
      setSceneElapsed(0);
    } else {
      setSceneElapsed(currentScene.durationSec);
      setIsPlaying(false);
      if (!watchedVideos.includes(currentVideo.id)) {
        setWatchedVideos((prev) => [...prev, currentVideo.id]);
      }
    }
  };

  const completedScenesSeconds = currentVideo.scenes
    .slice(0, currentSceneIndex)
    .reduce((acc, s) => acc + s.durationSec, 0);
  const totalElapsedSeconds = completedScenesSeconds + sceneElapsed;
  const totalProgressPercent = Math.min(
    100,
    (totalElapsedSeconds / currentVideo.totalSeconds) * 100
  );

  const handleAskVideoAI = async (customPrompt?: string) => {
    const q = (customPrompt ?? aiQuestion).trim();
    if (!q || aiLoading) return;
    setAiLoading(true);
    setAiResponse(null);
    try {
      const res = await fetch('/api/ai/counselor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: q,
          context: `Học sinh đang xem Video Hoạt hình bài học Chương ${currentVideo.chapterNumber}: "${currentVideo.title}". Tóm tắt bài học: ${currentVideo.summary}`,
        }),
      });
      const data = await res.json();
      setAiResponse(data.advice || 'Cẩm nang đã ghi nhận câu hỏi của bạn.');
    } catch {
      setAiResponse(
        'Hiện tại kết nối đang bận. Hãy nhớ bài học cốt lõi từ video: Cơ thể bạn là ngôi nhà sự sống quý giá, giá trị của bạn bắt nguồn từ trí tuệ và lòng nhân hậu!'
      );
    } finally {
      setAiLoading(false);
    }
  };

  // RENDER ANIMATED SHORT CARTOON SCENE (Bộ Hoạt Hình Sống Động)
  const renderAnimatedCartoonVignette = (theme: VideoScene['visualTheme']) => {
    const isTick = Math.floor(sceneElapsed * 2) % 2 === 0;

    switch (theme) {
      case 'mirror':
        return (
          <div className="relative w-full max-w-[280px] h-[210px] bg-gradient-to-b from-teal-950/80 to-slate-900 rounded-2xl p-3 border-2 border-teal-500/40 shadow-xl overflow-hidden flex items-center justify-around">
            {/* Ambient Animated Glow */}
            <div className="absolute -top-10 -left-10 w-24 h-24 bg-teal-400/20 rounded-full blur-xl animate-pulse" />

            {/* Cartoon Student Character */}
            <div className="flex flex-col items-center z-10">
              <div
                className={`w-12 h-12 rounded-full bg-amber-200 border-2 border-amber-400 flex items-center justify-center relative transition-transform duration-300 ${
                  isPlaying ? 'translate-y-[-2px]' : ''
                }`}
              >
                {/* Hair */}
                <div className="absolute -top-1 w-13 h-5 bg-slate-800 rounded-t-full" />
                {/* Eyes */}
                <div className="flex gap-2.5 mt-2">
                  <div className="w-1.5 h-1.5 bg-slate-900 rounded-full animate-bounce" />
                  <div className="w-1.5 h-1.5 bg-slate-900 rounded-full animate-bounce" />
                </div>
                {/* Smile / Mouth */}
                <div className="w-3 h-1.5 border-b-2 border-slate-800 rounded-full mt-1" />
              </div>
              {/* Uniform Body */}
              <div className="w-14 h-12 bg-teal-700 rounded-t-xl border-x border-teal-500 flex items-center justify-center mt-1">
                <span className="text-[8px] font-bold text-teal-100 bg-teal-900 px-1 rounded">THPT</span>
              </div>
              {/* Legs */}
              <div className="flex gap-2">
                <div className="w-2.5 h-6 bg-slate-800" />
                <div className="w-2.5 h-6 bg-slate-800" />
              </div>
            </div>

            {/* Full-Length Cartoon Mirror */}
            <div className="w-24 h-40 rounded-full bg-gradient-to-b from-cyan-200/30 via-teal-300/20 to-cyan-100/10 border-4 border-amber-300/80 shadow-inner flex flex-col items-center justify-center relative backdrop-blur-xs">
              <div className="absolute top-2 w-16 h-1 bg-white/40 rounded-full" />
              <div className="text-center p-1">
                <Sparkles className="w-6 h-6 text-amber-300 mx-auto animate-spin" style={{ animationDuration: '6s' }} />
                <div className="text-[9px] font-extrabold text-teal-200 mt-1 leading-tight">
                  Trung Dung Cơ Thể
                </div>
                <div className="text-[8px] text-teal-300 mt-0.5">Khỏe mạnh &amp; Trân trọng</div>
              </div>
              {/* Stand */}
              <div className="absolute -bottom-2 w-12 h-2 bg-amber-400 rounded-full" />
            </div>

            {/* Floating Thought / Heart Bubbles */}
            <div className="absolute top-3 right-3 animate-bounce">
              <div className="bg-white/90 text-slate-900 text-[9px] font-bold px-2 py-0.5 rounded-full shadow-md flex items-center gap-1">
                <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
                <span>Yêu quý bản thân</span>
              </div>
            </div>
          </div>
        );

      case 'shield':
        return (
          <div className="relative w-full max-w-[280px] h-[210px] bg-gradient-to-b from-amber-950/80 to-slate-900 rounded-2xl p-3 border-2 border-amber-500/40 shadow-xl overflow-hidden flex items-center justify-between">
            {/* Left: Teasing Words Coming In (Red Bullets) */}
            <div className="flex flex-col gap-2 z-10 pl-2">
              <div className={`px-2 py-1 rounded-lg bg-rose-900/90 border border-rose-400 text-rose-200 text-[9px] font-bold shadow-md transition-transform ${isTick ? 'translate-x-1' : ''}`}>
                "Dạo này mập thế?"
              </div>
              <div className="flex items-center gap-1 text-rose-400 text-[10px] font-bold">
                <Zap className="w-3.5 h-3.5 animate-pulse" />
                <span>Bình phẩm</span>
              </div>
            </div>

            {/* Glowing Golden & Emerald Forcefield Shield */}
            <div className="relative flex items-center justify-center mx-auto z-20">
              <div className="w-16 h-28 rounded-r-full bg-gradient-to-r from-emerald-400/30 via-teal-300/40 to-amber-300/30 border-r-4 border-amber-300 shadow-[0_0_20px_rgba(52,211,153,0.5)] flex items-center justify-center animate-pulse">
                <Shield className="w-8 h-8 text-amber-300" />
              </div>
              <div className="absolute -top-3 text-[9px] font-black text-amber-300 bg-amber-950 px-2 py-0.5 rounded-full border border-amber-400">
                TẤM KHIÊN TÂM LÝ
              </div>
            </div>

            {/* Right: Confident Student Character */}
            <div className="flex flex-col items-center z-10 pr-2">
              <div className="w-11 h-11 rounded-full bg-amber-100 border-2 border-amber-400 flex items-center justify-center relative">
                <div className="flex gap-2">
                  <div className="w-1.5 h-1.5 bg-slate-900 rounded-full" />
                  <div className="w-1.5 h-1.5 bg-slate-900 rounded-full" />
                </div>
                <div className="absolute bottom-1 w-3.5 h-1.5 bg-emerald-700 rounded-full" />
              </div>
              <div className="w-12 h-10 bg-emerald-800 rounded-t-lg mt-1 flex items-center justify-center text-[8px] font-bold text-white">
                Điềm Tĩnh
              </div>
              <div className="flex gap-1.5">
                <div className="w-2 h-5 bg-slate-900" />
                <div className="w-2 h-5 bg-slate-900" />
              </div>
            </div>
          </div>
        );

      case 'tree':
        return (
          <div className="relative w-full max-w-[280px] h-[210px] bg-gradient-to-b from-emerald-950/80 to-slate-900 rounded-2xl p-3 border-2 border-emerald-500/40 shadow-xl overflow-hidden flex flex-col items-center justify-center">
            {/* Animated Foliage / Tree Top */}
            <div className="relative flex items-center justify-center">
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-emerald-600 via-teal-500 to-green-400 border-2 border-emerald-300 shadow-lg flex items-center justify-center animate-pulse">
                <span className="text-[10px] font-black text-emerald-950 text-center leading-tight">
                  LÒNG TỰ TRỌNG
                </span>
              </div>
              {/* 5 Orbiting Pillar Badges */}
              <div className="absolute -top-2 -left-3 bg-amber-400 text-slate-950 text-[8px] font-black px-1.5 py-0.5 rounded-full shadow-md animate-bounce">
                1. Trí Tuệ
              </div>
              <div className="absolute -top-2 -right-3 bg-rose-400 text-slate-950 text-[8px] font-black px-1.5 py-0.5 rounded-full shadow-md animate-bounce" style={{ animationDelay: '0.3s' }}>
                2. Tử Tế
              </div>
              <div className="absolute -bottom-1 -left-4 bg-cyan-400 text-slate-950 text-[8px] font-black px-1.5 py-0.5 rounded-full shadow-md animate-bounce" style={{ animationDelay: '0.6s' }}>
                3. Kiên Trì
              </div>
              <div className="absolute -bottom-1 -right-4 bg-purple-400 text-slate-950 text-[8px] font-black px-1.5 py-0.5 rounded-full shadow-md animate-bounce" style={{ animationDelay: '0.9s' }}>
                4. Gắn Kết
              </div>
            </div>

            {/* Tree Trunk & Roots */}
            <div className="w-6 h-10 bg-amber-800 rounded-b border-x border-amber-900 mt-0.5 flex flex-col items-center justify-center">
              <div className="w-12 h-1 bg-amber-600 rounded-full mt-auto" />
            </div>
            <div className="text-[10px] font-bold text-emerald-200 mt-1">
              5 Trụ Cột Giá Trị Cốt Lõi
            </div>
          </div>
        );

      case 'phone':
        return (
          <div className="relative w-full max-w-[280px] h-[210px] bg-gradient-to-b from-indigo-950/80 to-slate-900 rounded-2xl p-3 border-2 border-indigo-500/40 shadow-xl overflow-hidden flex flex-col items-center justify-center">
            {/* Animated Smartphone Mockup */}
            <div className="w-36 h-40 bg-slate-950 rounded-2xl border-2 border-indigo-400 shadow-2xl p-2 flex flex-col justify-between relative overflow-hidden">
              <div className="w-10 h-1 bg-slate-700 rounded-full mx-auto" />

              {/* In-Phone Screen: Real Face vs Filter Layer */}
              <div className="flex-1 bg-slate-900 rounded-xl my-1 p-1.5 flex flex-col items-center justify-center relative overflow-hidden">
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-200 to-rose-200 border-2 border-white flex items-center justify-center">
                  <Smile className="w-7 h-7 text-slate-800" />
                </div>
                {/* Floating Filter Overlay */}
                <div className="absolute top-1 right-1 bg-rose-500 text-white text-[7px] font-bold px-1 rounded-full animate-pulse">
                  ẢNH TỰ NHIÊN
                </div>
                <div className="text-[9px] font-bold text-indigo-200 mt-1">
                  Ảo Ảnh Hoàn Hảo
                </div>
              </div>

              {/* Social Media Heart & Detox Bar */}
              <div className="flex items-center justify-between text-[8px] text-slate-300 px-1">
                <span className="flex items-center gap-1 text-rose-400 font-bold">
                  <Heart className="w-2.5 h-2.5 fill-rose-500 text-rose-500" /> Mặt Mộc
                </span>
                <span className="text-teal-300 font-bold">Thanh Lọc MXH</span>
              </div>
            </div>
          </div>
        );

      case 'community':
        return (
          <div className="relative w-full max-w-[280px] h-[210px] bg-gradient-to-b from-emerald-950/80 to-slate-900 rounded-2xl p-3 border-2 border-emerald-500/40 shadow-xl overflow-hidden flex items-center justify-around">
            {/* Two Classmates Character Puppets */}
            <div className="flex items-center gap-3">
              {/* Upstander Friend */}
              <div className="flex flex-col items-center">
                <div className="w-10 h-10 rounded-full bg-amber-200 border-2 border-amber-400 flex items-center justify-center">
                  <div className="flex gap-1.5">
                    <div className="w-1 h-1 bg-slate-900 rounded-full" />
                    <div className="w-1 h-1 bg-slate-900 rounded-full" />
                  </div>
                </div>
                <div className="w-10 h-9 bg-teal-600 rounded-t-lg mt-0.5 text-[7px] font-bold text-white flex items-center justify-center">
                  Người Bảo Vệ
                </div>
              </div>

              {/* Heart Connection Bridge */}
              <div className="flex flex-col items-center">
                <div className="w-10 h-10 rounded-full bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center border-2 border-white shadow-lg animate-bounce">
                  5s
                </div>
                <span className="text-[8px] font-bold text-amber-300 mt-1">Quy Tắc Vàng</span>
              </div>

              {/* Protected Friend */}
              <div className="flex flex-col items-center">
                <div className="w-10 h-10 rounded-full bg-rose-200 border-2 border-rose-400 flex items-center justify-center">
                  <div className="flex gap-1.5">
                    <div className="w-1 h-1 bg-slate-900 rounded-full" />
                    <div className="w-1 h-1 bg-slate-900 rounded-full" />
                  </div>
                </div>
                <div className="w-10 h-9 bg-indigo-600 rounded-t-lg mt-0.5 text-[7px] font-bold text-white flex items-center justify-center">
                  Bạn Học
                </div>
              </div>
            </div>

            <div className="absolute bottom-2 text-[9px] font-extrabold text-teal-200 bg-teal-950/80 px-3 py-0.5 rounded-full border border-teal-500/40">
              Lớp Học Yêu Thương • Tôn Trọng
            </div>
          </div>
        );

      case 'breathing':
      default: {
        const breathPhase = Math.floor(sceneElapsed) % 19;
        let breathLabel = 'Hít Vào (4s)';
        let breathScale = 'scale-110';
        let breathColor = 'from-cyan-400 to-teal-500';
        if (breathPhase >= 4 && breathPhase < 11) {
          breathLabel = 'Giữ Hơi (7s)';
          breathScale = 'scale-115';
          breathColor = 'from-emerald-400 to-teal-400';
        } else if (breathPhase >= 11) {
          breathLabel = 'Thở Ra (8s)';
          breathScale = 'scale-90';
          breathColor = 'from-indigo-400 to-cyan-500';
        }

        return (
          <div className="relative w-full max-w-[280px] h-[210px] bg-gradient-to-b from-cyan-950/80 to-slate-900 rounded-2xl p-3 border-2 border-cyan-500/40 shadow-xl overflow-hidden flex flex-col items-center justify-center">
            {/* Pulsing Breathing Mandala Circle */}
            <div
              className={`w-28 h-28 rounded-full bg-gradient-to-tr ${breathColor} border-4 border-white shadow-[0_0_30px_rgba(34,211,238,0.5)] flex flex-col items-center justify-center text-slate-950 font-black transition-all duration-1000 ${
                isPlaying ? breathScale : 'scale-100'
              }`}
            >
              <Wind className="w-8 h-8 mb-0.5" />
              <div className="text-[10px] font-black">{breathLabel}</div>
            </div>

            <div className="text-[10px] font-bold text-cyan-200 mt-3 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>Phương Pháp Thở Khoa Học 4 - 7 - 8</span>
            </div>
          </div>
        );
      }
    }
  };

  return (
    <div className="pb-14 space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 text-white rounded-2xl p-6 sm:p-8 border border-teal-800/40 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-300">
              <Film className="w-4 h-4 text-amber-400" />
              <span>PHÒNG CHIẾU HOẠT HÌNH MINH HỌA CẨM NANG</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              Video &amp; Hoạt Hình Minh Họa Bài Học Cẩm Nang
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Trải nghiệm các bộ hoạt cảnh chuyển động sống động, nhân vật học sinh trực quan, phụ đề lời giảng và thuyết minh tiếng Việt. Giúp bạn thấu hiểu sâu sắc từng bài học tâm lý học đường qua thị giác sinh động.
            </p>
          </div>

          {/* View Mode Switcher: Motion Cartoon vs Comic Strip */}
          <div className="flex items-center gap-2 bg-white/10 p-1.5 rounded-xl border border-white/15 self-start md:self-center">
            <button
              onClick={() => setViewMode('cartoon_player')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                viewMode === 'cartoon_player'
                  ? 'bg-teal-500 text-slate-950 shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Tv className="w-3.5 h-3.5" />
              <span>Rạp Hoạt Hình</span>
            </button>
            <button
              onClick={() => setViewMode('comic_strip')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                viewMode === 'comic_strip'
                  ? 'bg-teal-500 text-slate-950 shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Khung Truyện Tranh</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Layout: Left Player + Right Playlist */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left 8 cols: Interactive Motion Cartoon Stage + Lesson Details */}
        <div className="lg:col-span-8 space-y-6">
          {viewMode === 'cartoon_player' ? (
            /* MOTION CARTOON PLAYER */
            <div className="bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
              {/* Top Video Status Bar */}
              <div className="flex flex-wrap items-center justify-between gap-2 px-4 sm:px-6 py-3 bg-slate-900/90 border-b border-slate-800 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-teal-300 font-bold">{currentVideo.category}</span>
                  <span className="text-slate-600">·</span>
                  <span className="text-slate-300 font-medium">
                    Cảnh {currentSceneIndex + 1}/{currentVideo.scenes.length}: {currentScene.sceneTitle}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {isPlaying && (
                    <span className="inline-flex items-center gap-1.5 text-[11px] text-emerald-400 font-semibold">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      Hoạt cảnh đang phát
                    </span>
                  )}
                  {onOpenHandbookChapter && (
                    <button
                      onClick={() => onOpenHandbookChapter(currentVideo.chapterId)}
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-teal-300 hover:text-teal-200 underline underline-offset-2"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>Xem cẩm nang</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Main Animated Visual Stage */}
              <div className="relative min-h-[380px] sm:min-h-[430px] p-6 sm:p-8 flex flex-col justify-between bg-gradient-to-br from-slate-950 via-teal-950/80 to-slate-900 text-white select-none">
                {/* Scene Content Grid */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center my-auto">
                  {/* Dynamic Animated Cartoon Character Vignette */}
                  <div className="md:col-span-5 flex flex-col items-center justify-center gap-3">
                    {renderAnimatedCartoonVignette(currentScene.visualTheme)}

                    {currentScene.highlightStat && (
                      <div className="mt-1 bg-white/10 backdrop-blur border border-white/15 rounded-xl px-3 py-1.5 text-center max-w-[220px]">
                        <div className="text-base font-black text-amber-300 tabular-nums">
                          {currentScene.highlightStat.value}
                        </div>
                        <div className="text-[10px] text-slate-200 leading-snug">
                          {currentScene.highlightStat.label}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Animated Lesson Slide Content Column */}
                  <div className="md:col-span-7 space-y-3.5">
                    <div className="text-[11px] font-bold text-teal-300 tracking-wide flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>PHÂN CẢNH HOẠT HÌNH 0{currentSceneIndex + 1}</span>
                    </div>

                    <h2 className="text-lg sm:text-xl font-black text-white leading-snug">
                      {currentScene.onScreenHeadline}
                    </h2>

                    {/* Key Visual Bullet Points */}
                    <div className="space-y-2 pt-1">
                      {currentScene.onScreenBullets.map((bullet, idx) => (
                        <div
                          key={idx}
                          className="flex items-start gap-2.5 bg-white/5 border border-white/10 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-slate-100"
                        >
                          <CheckCircle2 className="w-4 h-4 text-teal-400 flex-shrink-0 mt-0.5" />
                          <span>{bullet}</span>
                        </div>
                      ))}
                    </div>

                    {/* Dialogue Bubble */}
                    {currentScene.dialogue && (
                      <div className="mt-3 p-3 rounded-xl bg-slate-900/95 border border-teal-500/30 space-y-1.5 shadow-md">
                        <div className="text-[10px] font-bold text-amber-300">
                          LỜI THOẠI NHÂN VẬT HOẠT HÌNH:
                        </div>
                        {currentScene.dialogue.map((d, i) => (
                          <div key={i} className="text-xs leading-relaxed">
                            <span
                              className={`font-bold ${
                                d.role === 'mentor'
                                  ? 'text-teal-300'
                                  : d.role === 'peer'
                                  ? 'text-rose-300'
                                  : 'text-amber-300'
                              }`}
                            >
                              {d.speaker}:{' '}
                            </span>
                            <span className="text-slate-200 italic">"{d.line}"</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Subtitle / Closed Caption Bar */}
                {showCaptions && (
                  <div className="mt-4 pt-2">
                    <div className="bg-black/80 backdrop-blur-xs border border-white/10 rounded-xl px-4 py-2.5 text-center">
                      <p className="text-xs sm:text-sm text-amber-100 font-medium leading-relaxed">
                        <span className="text-teal-300 font-bold mr-1.5">[Thuyết minh]:</span>
                        {currentScene.narration}
                      </p>
                    </div>
                  </div>
                )}

                {/* Big Play Overlay when paused at start */}
                {!isPlaying && currentSceneIndex === 0 && sceneElapsed === 0 && (
                  <div className="absolute inset-0 bg-slate-950/50 backdrop-blur-[2px] flex items-center justify-center">
                    <button
                      onClick={handleTogglePlay}
                      className="flex items-center gap-3 px-6 py-3.5 rounded-2xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-black text-sm shadow-xl transition-all cursor-pointer"
                    >
                      <Play className="w-5 h-5 fill-slate-950" />
                      <span>Xem Hoạt Hình Minh Họa ({currentVideo.duration})</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Timeline Progress & Controls */}
              <div className="px-4 sm:px-6 pt-3 pb-2.5 bg-slate-900 border-t border-slate-800">
                {/* Segmented Scene Progress Bar */}
                <div className="grid grid-cols-4 gap-1.5 mb-2.5">
                  {currentVideo.scenes.map((scene, idx) => {
                    let fillPct = 0;
                    if (idx < currentSceneIndex) fillPct = 100;
                    else if (idx === currentSceneIndex) {
                      fillPct = Math.min(100, (sceneElapsed / scene.durationSec) * 100);
                    }
                    return (
                      <button
                        key={scene.id}
                        onClick={() => {
                          setCurrentSceneIndex(idx);
                          setSceneElapsed(0);
                          setIsPlaying(true);
                        }}
                        className="group text-left focus:outline-none"
                      >
                        <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-teal-400 transition-all duration-100"
                            style={{ width: `${fillPct}%` }}
                          />
                        </div>
                        <div className="mt-1 text-[10px] text-slate-400 group-hover:text-teal-300 truncate">
                          {scene.timestamp} • {scene.sceneTitle}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Control Buttons */}
                <div className="flex flex-wrap items-center justify-between gap-3 py-1.5 text-xs text-slate-300">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleTogglePlay}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold transition-colors cursor-pointer"
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      <span>{isPlaying ? 'Tạm dừng' : 'Phát'}</span>
                    </button>

                    <button
                      onClick={handlePrevScene}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                      title="Cảnh trước"
                    >
                      <SkipBack className="w-4 h-4" />
                    </button>

                    <button
                      onClick={handleNextScene}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                      title="Cảnh tiếp theo"
                    >
                      <SkipForward className="w-4 h-4" />
                    </button>

                    <button
                      onClick={handleRestart}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                      title="Phát lại từ đầu"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>

                    <span className="text-[11px] text-slate-400 ml-1 tabular-nums">
                      {Math.round(totalProgressPercent)}%
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setVoiceEnabled((v) => !v)}
                      className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition-colors border ${
                        voiceEnabled
                          ? 'bg-teal-950 border-teal-500/50 text-teal-300'
                          : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                      }`}
                      title="Bật/Tắt đọc thuyết minh tiếng Việt"
                    >
                      {voiceEnabled ? (
                        <Volume2 className="w-3.5 h-3.5 text-teal-400" />
                      ) : (
                        <VolumeX className="w-3.5 h-3.5" />
                      )}
                      <span>Thuyết minh</span>
                    </button>

                    <button
                      onClick={() => setShowCaptions((c) => !c)}
                      className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition-colors border ${
                        showCaptions
                          ? 'bg-teal-950 border-teal-500/50 text-teal-300'
                          : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Subtitles className="w-3.5 h-3.5" />
                      <span>Phụ đề</span>
                    </button>

                    <button
                      onClick={() => {
                        const speeds = [0.75, 1, 1.25, 1.5];
                        const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
                        setPlaybackSpeed(speeds[nextIdx]);
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-bold text-slate-200 tabular-nums"
                    >
                      {playbackSpeed}x
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* COMIC STRIP STORYBOARD VIEW */
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-6">
              <div className="border-b border-slate-100 pb-3">
                <h3 className="text-sm font-bold text-slate-900">
                  Tập Hoạt Họa Tranh Minh Họa: {currentVideo.title}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Theo dõi toàn bộ các phân cảnh hoạt hình dưới dạng khung truyện tranh giáo khoa
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {currentVideo.scenes.map((scene, i) => (
                  <div
                    key={scene.id}
                    className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-3 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs mb-2">
                        <span className="font-bold text-teal-700">Khung Cảnh 0{i + 1}</span>
                        <span className="px-2 py-0.5 bg-teal-100 text-teal-900 font-mono text-[10px] rounded font-bold">
                          {scene.timestamp}
                        </span>
                      </div>
                      <div className="my-2 flex justify-center">
                        {renderAnimatedCartoonVignette(scene.visualTheme)}
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 mt-2">
                        {scene.onScreenHeadline}
                      </h4>
                      <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                        {scene.narration}
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        setCurrentSceneIndex(i);
                        setSceneElapsed(0);
                        setViewMode('cartoon_player');
                        setIsPlaying(true);
                      }}
                      className="w-full py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-[11px] font-bold transition-colors flex items-center justify-center gap-1"
                    >
                      <Play className="w-3 h-3 fill-white" />
                      <span>Xem hoạt hình cảnh này</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Interactive Lesson Study Tabs Below Video */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <div className="text-xs font-bold text-teal-700 mb-1">
                  {currentVideo.category} • Thời lượng {currentVideo.duration}
                </div>
                <h2 className="text-lg sm:text-xl font-black text-slate-900">
                  {currentVideo.title}
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 mt-1">{currentVideo.subtitle}</p>
              </div>

              <button
                onClick={() => {
                  setWatchedVideos((prev) =>
                    prev.includes(currentVideo.id)
                      ? prev.filter((id) => id !== currentVideo.id)
                      : [...prev, currentVideo.id]
                  );
                }}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-colors ${
                  watchedVideos.includes(currentVideo.id)
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {watchedVideos.includes(currentVideo.id)
                    ? 'Đã hoàn thành bài học'
                    : 'Đánh dấu đã xem'}
                </span>
              </button>
            </div>

            {/* Sub Tabs */}
            <div className="flex flex-wrap items-center gap-2 bg-slate-100 p-1.5 rounded-xl">
              <button
                onClick={() => setActiveBottomTab('timestamps')}
                className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                  activeBottomTab === 'timestamps'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                1. Mốc thời gian &amp; Tóm tắt hoạt hình
              </button>
              <button
                onClick={() => setActiveBottomTab('quiz')}
                className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                  activeBottomTab === 'quiz'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                2. Ôn tập nhanh ({currentVideo.quiz.length} câu)
              </button>
              <button
                onClick={() => setActiveBottomTab('ai')}
                className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                  activeBottomTab === 'ai'
                    ? 'bg-white text-teal-800 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                3. Gửi thắc mắc về bài học
              </button>
            </div>

            {/* Tab 1: Timestamps */}
            {activeBottomTab === 'timestamps' && (
              <div className="space-y-5">
                <div className="p-4 rounded-xl bg-teal-50/70 border border-teal-200/80 text-xs sm:text-sm text-slate-700 leading-relaxed">
                  <strong className="text-teal-900">Tóm tắt nội dung: </strong>
                  {currentVideo.summary}
                </div>

                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
                    Các phân cảnh hoạt hình (Nhấn để chuyển nhanh)
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {currentVideo.scenes.map((scene, idx) => {
                      const isCurrent = idx === currentSceneIndex;
                      return (
                        <button
                          key={scene.id}
                          onClick={() => {
                            setCurrentSceneIndex(idx);
                            setSceneElapsed(0);
                            setIsPlaying(true);
                            setViewMode('cartoon_player');
                          }}
                          className={`text-left p-3.5 rounded-xl border transition-all flex items-start gap-3 ${
                            isCurrent
                              ? 'bg-teal-50/90 border-teal-400 text-teal-950 shadow-xs'
                              : 'bg-slate-50/70 hover:bg-slate-100 border-slate-200/80 text-slate-700'
                          }`}
                        >
                          <span className="px-2 py-0.5 rounded bg-teal-700 text-white font-mono text-[11px] font-bold tabular-nums mt-0.5">
                            {scene.timestamp}
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-bold text-slate-900">
                              {scene.sceneTitle}
                            </div>
                            <p className="text-[11px] text-slate-600 line-clamp-2 mt-1">
                              {scene.narration}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="border-t border-slate-100 pt-4">
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2.5">
                    3 Điểm Nhớ Cốt Lõi Từ Cẩm Nang
                  </h3>
                  <ul className="space-y-2">
                    {currentVideo.keyTakeaways.map((kt, i) => (
                      <li key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700">
                        <Sparkles className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                        <span>{kt}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {/* Tab 2: Quiz */}
            {activeBottomTab === 'quiz' && (
              <div className="space-y-4">
                <div className="text-xs text-slate-600">
                  Chọn đáp án đúng nhất để kiểm tra mức độ nắm vững bài học hoạt hình:
                </div>
                {currentVideo.quiz.map((q, qIdx) => {
                  const selectedOpt = quizAnswers[q.id];
                  const hasAnswered = selectedOpt !== undefined;
                  const isCorrect = selectedOpt === q.correctIndex;

                  return (
                    <div
                      key={q.id}
                      className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3"
                    >
                      <div className="text-xs sm:text-sm font-bold text-slate-900 flex items-start gap-2">
                        <HelpCircle className="w-4 h-4 text-teal-600 flex-shrink-0 mt-0.5" />
                        <span>
                          Câu {qIdx + 1}: {q.question}
                        </span>
                      </div>
                      <div className="space-y-2">
                        {q.options.map((opt, optIdx) => {
                          const isThisSelected = selectedOpt === optIdx;
                          let btnStyle =
                            'bg-white hover:bg-slate-100 border-slate-200 text-slate-700';
                          if (hasAnswered) {
                            if (optIdx === q.correctIndex) {
                              btnStyle =
                                'bg-emerald-50 border-emerald-400 text-emerald-900 font-semibold';
                            } else if (isThisSelected) {
                              btnStyle = 'bg-rose-50 border-rose-300 text-rose-900';
                            }
                          }
                          return (
                            <button
                              key={optIdx}
                              onClick={() =>
                                setQuizAnswers((prev) => ({ ...prev, [q.id]: optIdx }))
                              }
                              className={`w-full text-left px-3.5 py-2.5 rounded-lg border text-xs transition-all flex items-center justify-between gap-2 ${btnStyle}`}
                            >
                              <span>{opt}</span>
                              {hasAnswered && optIdx === q.correctIndex && (
                                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                              )}
                            </button>
                          );
                        })}
                      </div>

                      {hasAnswered && (
                        <div
                          className={`p-3 rounded-lg text-xs leading-relaxed ${
                            isCorrect
                              ? 'bg-emerald-100/70 text-emerald-950'
                              : 'bg-amber-50 text-amber-950'
                          }`}
                        >
                          <strong>{isCorrect ? 'Chính xác! ' : 'Gợi ý từ Cẩm nang: '}</strong>
                          {q.explanation}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Tab 3: Ask questions */}
            {activeBottomTab === 'ai' && (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-gradient-to-r from-teal-50 to-emerald-50 border border-teal-200 text-xs text-teal-950 space-y-2">
                  <div className="font-bold flex items-center gap-1.5 text-teal-800">
                    <MessageSquare className="w-4 h-4" />
                    <span>Giải đáp thắc mắc về bài giảng "{currentVideo.title}"</span>
                  </div>
                  <p className="text-slate-600">
                    Nhập câu hỏi hoặc chọn câu hỏi gợi ý để nhận giải đáp áp dụng bài học vào thực tế:
                  </p>
                  <div className="flex flex-wrap gap-2 pt-1">
                    <button
                      onClick={() => {
                        const prompt = `Làm sao để em áp dụng bài học trong video hoạt hình "${currentVideo.title}" vào thực tế mỗi ngày ở trường?`;
                        setAiQuestion(prompt);
                        handleAskVideoAI(prompt);
                      }}
                      className="text-[11px] bg-white hover:bg-teal-100/60 text-teal-800 border border-teal-200 px-3 py-1 rounded-lg font-medium transition-colors"
                    >
                      Gợi ý 1: Cách áp dụng bài học này mỗi ngày?
                    </button>
                    <button
                      onClick={() => {
                        const prompt = `Em hiểu lý thuyết trong video "${currentVideo.title}" nhưng đôi khi vẫn thấy chạnh lòng khi bị bạn bè nhận xét. Em nên bắt đầu từ bước nhỏ nào?`;
                        setAiQuestion(prompt);
                        handleAskVideoAI(prompt);
                      }}
                      className="text-[11px] bg-white hover:bg-teal-100/60 text-teal-800 border border-teal-200 px-3 py-1 rounded-lg font-medium transition-colors"
                    >
                      Gợi ý 2: Làm sao vượt qua cảm giác chạnh lòng?
                    </button>
                  </div>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={aiQuestion}
                    onChange={(e) => setAiQuestion(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAskVideoAI()}
                    placeholder="Nhập câu hỏi của bạn về bài học trong video..."
                    className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm focus:outline-none focus:border-teal-600"
                  />
                  <button
                    onClick={() => handleAskVideoAI()}
                    disabled={aiLoading || !aiQuestion.trim()}
                    className="px-4 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    {aiLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                    <span>Gửi câu hỏi</span>
                  </button>
                </div>

                {aiResponse && (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                    <div className="font-bold text-teal-800 mb-1.5 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-500" />
                      <span>Gợi ý định hướng từ Cẩm nang:</span>
                    </div>
                    {aiResponse}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right 4 cols: Playlist */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs sticky top-24">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-xs font-bold text-teal-700">DANH SÁCH BỘ HOẠT HÌNH</div>
                <h3 className="text-sm font-extrabold text-slate-900">
                  6 Tập Hoạt Hình Cẩm Nang
                </h3>
              </div>
              <span className="text-xs font-semibold text-slate-500 tabular-nums">
                {LESSON_VIDEOS.length} tập
              </span>
            </div>

            <div className="space-y-2.5">
              {LESSON_VIDEOS.map((video) => {
                const isSelected = video.id === currentVideo.id;
                const isDone = watchedVideos.includes(video.id);

                return (
                  <button
                    key={video.id}
                    onClick={() => handleSelectVideo(video)}
                    className={`w-full text-left p-3 rounded-xl border transition-all flex items-start gap-3 ${
                      isSelected
                        ? 'bg-teal-50/90 border-teal-400 text-teal-950 shadow-xs'
                        : 'bg-white hover:bg-slate-50 border-slate-200/70 text-slate-700'
                    }`}
                  >
                    <div
                      className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center flex-shrink-0 font-bold text-xs ${
                        isSelected
                          ? 'bg-teal-700 text-white'
                          : isDone
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {isDone ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      ) : (
                        <>
                          <Play className="w-4 h-4 mb-0.5" />
                          <span className="text-[9px] tabular-nums">Tập {video.chapterNumber}</span>
                        </>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-semibold text-teal-700">
                        {video.category}
                      </div>
                      <div className="text-xs font-bold text-slate-900 leading-snug line-clamp-2 mt-0.5">
                        {video.title}
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1">
                        <span className="inline-flex items-center gap-1 tabular-nums">
                          <Clock className="w-3 h-3" /> {video.duration}
                        </span>
                        <span>·</span>
                        <span>{video.scenes.length} hoạt cảnh</span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {onOpenHandbookChapter && (
              <div className="mt-5 pt-4 border-t border-slate-100">
                <button
                  onClick={() => onOpenHandbookChapter(currentVideo.chapterId)}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <BookOpen className="w-4 h-4 text-teal-300" />
                  <span>Đọc chi tiết văn bản Cẩm nang</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
