import React, { useState } from 'react';
import { SCENARIOS_DATA } from '../data/interactiveScenarios';
import { Scenario, ScenarioEvaluationResult } from '../types';
import {
  MessageSquare,
  Sparkles,
  School,
  Share2,
  Users,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Send,
  Loader2,
  Shield,
  HelpCircle,
  Award,
  Lightbulb,
  ArrowRight,
  TrendingUp,
  BrainCircuit,
  MessageCircleQuestion,
  PenTool,
} from 'lucide-react';

export const ScenarioSimulatorView: React.FC = () => {
  // Mode: Preset scenarios or 100% custom user scenario
  const [mode, setMode] = useState<'preset' | 'custom'>('preset');
  const [activeScenarioId, setActiveScenarioId] = useState<string>('sc-1');

  // Input states
  const [customSituationText, setCustomSituationText] = useState<string>('');
  const [userSolutionText, setUserSolutionText] = useState<string>('');

  // Evaluation state
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [evaluationResult, setEvaluationResult] = useState<ScenarioEvaluationResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const activeScenario =
    SCENARIOS_DATA.find((s) => s.id === activeScenarioId) || SCENARIOS_DATA[0];

  const currentSituation =
    mode === 'preset'
      ? `${activeScenario.title}: ${activeScenario.situation} (Câu chê bai: ${activeScenario.quote})`
      : customSituationText;

  const handleSelectPreset = (id: string) => {
    setActiveScenarioId(id);
    setUserSolutionText('');
    setEvaluationResult(null);
    setErrorMsg(null);
  };

  const handleEvaluate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg(null);

    const situationToSubmit = currentSituation.trim();
    const solutionToSubmit = userSolutionText.trim();

    if (!situationToSubmit) {
      setErrorMsg('Vui lòng nhập mô tả tình huống cần xử lý.');
      return;
    }
    if (!solutionToSubmit) {
      setErrorMsg('Vui lòng nhập cách giải quyết hoặc câu thoại đối đáp của bạn.');
      return;
    }

    setIsEvaluating(true);
    setEvaluationResult(null);

    try {
      const res = await fetch('/api/ai/scenario-evaluation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          situation: situationToSubmit,
          userSolution: solutionToSubmit,
        }),
      });

      if (!res.ok) {
        throw new Error('Lỗi phản hồi từ máy chủ.');
      }

      const data: ScenarioEvaluationResult = await res.json();
      setEvaluationResult(data);
    } catch (err: any) {
      // Fallback evaluation client-side if network issue occurs
      setEvaluationResult({
        score: 82,
        ratingLevel: 'good',
        ratingLabel: 'Phản Xạ Quyết Đoán & Tự Chủ',
        primaryStyle: 'assertive',
        styleName: 'Quyết đoán & Giữ ranh giới văn minh (Assertive)',
        dimensions: {
          selfBoundary: 8,
          deEscalation: 8,
          emotionalComposure: 8,
          civilPractical: 9,
        },
        peerReaction:
          'Đối phương sẽ cảm nhận được thái độ nghiêm túc, tự tin của bạn và nhận thấy trò đùa không còn buồn cười nữa.',
        pros: [
          'Bạn đã chủ động đứng lên bảo vệ cảm xúc của chính mình thay vì kìm nén.',
          'Giữ được thái độ lịch thiệp, không biến thành mâu thuẫn bạo lực học đường.',
        ],
        risksOrNotes: [
          'Hãy duy trì ánh mắt thẳng và giọng nói điềm đạm để lời nói có sức nặng nhất.',
        ],
        improvedVersion: `"${userSolutionText.trim()}" ➜ Gợi ý thêm: "Mỗi người có nét riêng, mình thấy hoàn toàn bình thường với điều đó. Tụi mình tôn trọng nhau nhé!"`,
        psychologicalMechanism:
          'Kỹ năng quyết đoán (Assertiveness) giúp bạn thiết lập ranh giới bảo vệ lòng tự trọng mà không gây hấn.',
      });
    } finally {
      setIsEvaluating(false);
    }
  };

  const getContextBadge = (context: Scenario['context']) => {
    switch (context) {
      case 'school':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 font-semibold">
            <School className="w-3.5 h-3.5" /> Học Đường
          </span>
        );
      case 'social_media':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-800 font-semibold">
            <Share2 className="w-3.5 h-3.5" /> Mạng Xã Hội
          </span>
        );
      case 'family':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-semibold">
            <Users className="w-3.5 h-3.5" /> Gia Đình / Họ Hàng
          </span>
        );
      case 'peer_pressure':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 font-semibold">
            <Users className="w-3.5 h-3.5" /> Bạn Bè / Nhóm Chat
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-8 pb-14">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-slate-900 to-teal-950 text-white rounded-2xl p-6 sm:p-8 border border-teal-800/40 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-300">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>PHÒNG LUYỆN TẬP PHẢN ỨNG THỰC CHIẾN ĐA CHIỀU</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              Đánh Giá Trực Tiếp Cách Ứng Phó Tình Huống Thực Tế
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Không gò bó theo đáp án trắc nghiệm cố định. Hãy chọn hoặc nhập tình huống thực tế và đưa ra cách xử lý của chính bạn — Hệ thống phân tích cẩm nang sẽ đánh giá trực tiếp hiệu quả đa chiều theo các tiêu chí tâm lý học đường.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-white/10 p-1.5 rounded-xl border border-white/15 self-start md:self-center">
            <button
              onClick={() => {
                setMode('preset');
                setEvaluationResult(null);
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all ${
                mode === 'preset'
                  ? 'bg-teal-500 text-slate-950 shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              5 Tình Huống Tiêu Biểu
            </button>
            <button
              onClick={() => {
                setMode('custom');
                setEvaluationResult(null);
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all ${
                mode === 'custom'
                  ? 'bg-teal-500 text-slate-950 shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Tự Nhập Tình Huống Của Bạn
            </button>
          </div>
        </div>
      </div>

      {/* Preset Scenario Selector Buttons */}
      {mode === 'preset' && (
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-800">Chọn 1 tình huống học đường để thực hành:</span>
            <span className="text-slate-500">{SCENARIOS_DATA.length} bối cảnh phổ biến</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {SCENARIOS_DATA.map((sc, idx) => {
              const isSelected = sc.id === activeScenario.id;
              return (
                <button
                  key={sc.id}
                  onClick={() => handleSelectPreset(sc.id)}
                  className={`p-3.5 rounded-xl text-left border transition-all flex flex-col justify-between gap-2 ${
                    isSelected
                      ? 'bg-teal-50/90 border-teal-500 shadow-xs ring-2 ring-teal-500/20'
                      : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-400">Tình huống 0{idx + 1}</span>
                    {getContextBadge(sc.context)}
                  </div>
                  <div className="text-xs font-bold text-slate-900 line-clamp-2 leading-snug">
                    {sc.title}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Main Workspace: Left Input Form + Right Real-time Evaluation Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Situation & User Solution Input */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200 shadow-xs space-y-5">
            {/* Situation Header */}
            {mode === 'preset' ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-teal-700 uppercase tracking-wider">
                    Bối cảnh tình huống thực tế
                  </span>
                  {getContextBadge(activeScenario.context)}
                </div>
                <h2 className="text-base sm:text-lg font-black text-slate-900 leading-snug">
                  {activeScenario.title}
                </h2>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {activeScenario.situation}
                </p>
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-950 text-xs sm:text-sm font-semibold italic">
                  {activeScenario.quote}
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <PenTool className="w-4 h-4 text-teal-600" />
                  <span>Mô tả tình huống bạn hoặc bạn bè gặp phải ngoài đời:</span>
                </label>
                <textarea
                  rows={3}
                  value={customSituationText}
                  onChange={(e) => setCustomSituationText(e.target.value)}
                  placeholder="Ví dụ: Trong giờ ra chơi, khi em đang ngồi uống nước với bạn thì một bạn nam bàn trên quay xuống trêu: 'Sao dạo này nhìn người gầy như bộ xương thế'... Em rất bối rối và khó chịu."
                  className="w-full px-4 py-3 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 bg-slate-50/50 resize-none"
                />
              </div>
            )}

            {/* Prompt Guidance Ideas if Preset */}
            {mode === 'preset' && activeScenario.suggestedPromptIdeas && (
              <div className="p-4 rounded-xl bg-teal-50/70 border border-teal-200/80 space-y-2">
                <div className="text-[11px] font-bold text-teal-900 flex items-center gap-1.5">
                  <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
                  <span>Gợi ý định hướng suy nghĩ từ Cẩm nang (bạn có thể tham khảo hoặc viết theo ý mình):</span>
                </div>
                <div className="space-y-1.5">
                  {activeScenario.suggestedPromptIdeas.map((idea, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setUserSolutionText(idea)}
                      className="w-full text-left p-2 rounded-lg bg-white hover:bg-teal-100/50 border border-teal-200/60 text-[11px] text-teal-950 transition-colors flex items-start gap-2"
                    >
                      <ArrowRight className="w-3.5 h-3.5 text-teal-600 flex-shrink-0 mt-0.5" />
                      <span>{idea}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Solution Input Area */}
            <form onSubmit={handleEvaluate} className="space-y-4 pt-2 border-t border-slate-100">
              <div>
                <label className="text-xs font-bold text-slate-900 flex items-center justify-between mb-2">
                  <span className="flex items-center gap-1.5">
                    <MessageSquare className="w-4 h-4 text-teal-600" />
                    <span>Cách xử lý &amp; Câu thoại đối đáp của bạn:</span>
                  </span>
                  <span className="text-[11px] text-slate-400 font-normal">
                    Tự do thể hiện phản xạ của bạn
                  </span>
                </label>
                <textarea
                  rows={4}
                  value={userSolutionText}
                  onChange={(e) => setUserSolutionText(e.target.value)}
                  placeholder="Bạn sẽ nói gì? Nét mặt và cử chỉ ra sao? Sau đó bạn sẽ làm gì tiếp theo? Hãy gõ câu trả lời tự nhiên của bạn vào đây..."
                  className="w-full px-4 py-3 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 bg-white resize-none"
                />
              </div>

              {errorMsg && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <div className="flex items-center justify-between gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setUserSolutionText('');
                    setEvaluationResult(null);
                    setErrorMsg(null);
                  }}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Làm mới</span>
                </button>

                <button
                  type="submit"
                  disabled={isEvaluating || !userSolutionText.trim()}
                  className="flex-1 py-3 px-5 rounded-xl bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-teal-600/20 transition-all cursor-pointer"
                >
                  {isEvaluating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Đang phân tích đa chiều theo thời gian thực...</span>
                    </>
                  ) : (
                    <>
                      <BrainCircuit className="w-4 h-4" />
                      <span>Đánh Giá Hiệu Quả Trực Tiếp</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Right Column: Real-time Multi-Dimensional Evaluation Result */}
        <div className="lg:col-span-6 space-y-6">
          {evaluationResult ? (
            <div className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200 shadow-md space-y-6 animate-in fade-in duration-300">
              {/* Header Score & Rating Badge */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <span className="text-[10px] font-bold text-teal-700 uppercase tracking-wider">
                    KẾT QUẢ ĐÁNH GIÁ ĐA CHIỀU
                  </span>
                  <h3 className="text-base sm:text-lg font-black text-slate-900 mt-0.5">
                    {evaluationResult.ratingLabel}
                  </h3>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Phong cách nhận diện: <strong>{evaluationResult.styleName}</strong>
                  </div>
                </div>

                {/* Score Circular Badge */}
                <div className="flex items-center gap-2 bg-gradient-to-br from-teal-50 to-emerald-50 border border-teal-200 px-4 py-2 rounded-2xl">
                  <Award className="w-6 h-6 text-teal-600" />
                  <div>
                    <div className="text-[10px] text-teal-800 font-bold">Điểm Hiệu Quả</div>
                    <div className="text-xl font-black text-teal-900 tabular-nums">
                      {evaluationResult.score}
                      <span className="text-xs font-semibold text-teal-700">/100</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 4 Core Psychological Dimensions Progress Bars */}
              <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
                <div className="text-xs font-bold text-slate-900 flex items-center justify-between">
                  <span>Phân tích 4 Chỉ số Tâm lý cốt lõi:</span>
                  <span className="text-[11px] text-slate-500 font-normal">Thang điểm 10</span>
                </div>

                <div className="space-y-2.5 pt-1">
                  {/* Dimension 1 */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-700 font-medium">1. Bảo vệ ranh giới &amp; Tôn trọng bản thân</span>
                      <span className="font-bold text-teal-900 tabular-nums">
                        {evaluationResult.dimensions.selfBoundary}/10
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-teal-500 transition-all duration-500"
                        style={{ width: `${evaluationResult.dimensions.selfBoundary * 10}%` }}
                      />
                    </div>
                  </div>

                  {/* Dimension 2 */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-700 font-medium">2. Xoa dịu &amp; Tránh leo thang xung đột</span>
                      <span className="font-bold text-teal-900 tabular-nums">
                        {evaluationResult.dimensions.deEscalation}/10
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 transition-all duration-500"
                        style={{ width: `${evaluationResult.dimensions.deEscalation * 10}%` }}
                      />
                    </div>
                  </div>

                  {/* Dimension 3 */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-700 font-medium">3. Điềm tĩnh &amp; Tự chủ cảm xúc</span>
                      <span className="font-bold text-teal-900 tabular-nums">
                        {evaluationResult.dimensions.emotionalComposure}/10
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-500 transition-all duration-500"
                        style={{ width: `${evaluationResult.dimensions.emotionalComposure * 10}%` }}
                      />
                    </div>
                  </div>

                  {/* Dimension 4 */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-700 font-medium">4. Tính văn minh &amp; Khả thi học đường</span>
                      <span className="font-bold text-teal-900 tabular-nums">
                        {evaluationResult.dimensions.civilPractical}/10
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-cyan-500 transition-all duration-500"
                        style={{ width: `${evaluationResult.dimensions.civilPractical * 10}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Peer Reaction Prediction */}
              <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200/80 text-xs sm:text-sm text-slate-800 space-y-1.5">
                <div className="font-bold text-amber-900 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-amber-600" />
                  <span>Dự báo phản ứng tâm lý của đối phương / người nghe:</span>
                </div>
                <p className="leading-relaxed text-slate-700">
                  {evaluationResult.peerReaction}
                </p>
              </div>

              {/* Pros & Risks Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Pros */}
                <div className="p-3.5 rounded-xl bg-emerald-50/80 border border-emerald-200 text-xs space-y-1.5">
                  <div className="font-bold text-emerald-900 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Điểm sáng trong cách xử lý:</span>
                  </div>
                  <ul className="space-y-1 text-emerald-950">
                    {evaluationResult.pros.map((pro, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-emerald-600">•</span>
                        <span>{pro}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Risks / Notes */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                  <div className="font-bold text-slate-900 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                    <span>Điểm cần lưu ý / Rủi ro:</span>
                  </div>
                  <ul className="space-y-1 text-slate-700">
                    {evaluationResult.risksOrNotes.map((note, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-amber-500">•</span>
                        <span>{note}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Improved Version Recommendation */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-teal-900 via-slate-900 to-teal-950 text-white space-y-2">
                <div className="text-xs font-bold text-teal-300 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>Phiên Bản Gợi Ý Nâng Cấp Từ Cẩm Nang (Giải pháp hoàn thiện):</span>
                </div>
                <div className="p-3 rounded-lg bg-white/10 border border-white/10 text-xs sm:text-sm font-medium text-amber-100 leading-relaxed italic">
                  {evaluationResult.improvedVersion}
                </div>
                <div className="text-[11px] text-slate-300 pt-1 leading-relaxed">
                  <strong>Cơ chế tâm lý học: </strong>
                  {evaluationResult.psychologicalMechanism}
                </div>
              </div>

              {/* Re-try / Refine Button */}
              <button
                onClick={() => {
                  window.scrollTo({ top: 350, behavior: 'smooth' });
                }}
                className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Thử nghiệm tinh chỉnh lại cách giải quyết</span>
              </button>
            </div>
          ) : (
            <div className="bg-slate-50 rounded-2xl p-8 sm:p-12 border-2 border-dashed border-slate-200 text-center text-slate-500 flex flex-col items-center justify-center min-h-[380px] space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-teal-100/60 text-teal-700 flex items-center justify-center">
                <BrainCircuit className="w-7 h-7" />
              </div>
              <h3 className="text-sm font-bold text-slate-800">
                Sẵn Sàng Đánh Giá Hiệu Quả Trực Tiếp
              </h3>
              <p className="text-xs text-slate-500 max-w-sm leading-relaxed">
                Sau khi bạn nhập câu thoại hoặc cách giải quyết ở bên trái và bấm <strong>"Đánh Giá Hiệu Quả Trực Tiếp"</strong>, hệ thống sẽ phân tích điểm số, 4 chỉ số tâm lý, dự báo phản ứng đối phương và đưa ra phiên bản nâng cấp hoàn hảo.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
